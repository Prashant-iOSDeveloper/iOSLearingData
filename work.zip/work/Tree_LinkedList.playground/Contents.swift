

import UIKit


class MyNode<T> {
    
    let value : T
    var next : MyNode?
    
    init(_ value : T , next : MyNode?) {
        
        self.value = value
        self.next = next
    }
        
}

class LinkedList<T> {
    
    var head : MyNode<T>?
    
    
    var last : MyNode<T>? {
        
        guard var node = head else {return nil}
        print(node.value)
        while node.next != nil {
          
            node = node.next!
            print(node.value)
         
        }
        return node
        
    }
    
    func insertNode (_ value : T) {
        if head == nil {
            head = MyNode(value, next: nil)
        }else {
            var currentnode = head
            while currentnode?.next != nil {
                currentnode = currentnode?.next
            }
            currentnode?.next = MyNode(value, next: nil)
        }
        
    }
    
    
    func deleteNode (_ value : T) {
        if head != nil {
            if head?.value as? Int == value as? Int {
                head = head?.next
            }            
            var current = head
            var prev : MyNode<T>?
            while current?.value as? Int != value as? Int {
                prev = current
                current = current?.next
               
            }
            prev?.next = current?.next
            
        }
    }
    
    func displayLinkedList(){
        print(last)
    }
    
}

let myLinkedList = LinkedList<Int>()
//
//myLinkedList.insertNode(1)
//myLinkedList.insertNode(2)
//myLinkedList.insertNode(4)
//myLinkedList.insertNode(8)
//myLinkedList.insertNode(81)
//myLinkedList.deleteNode(81)
//
//myLinkedList.displayLinkedList()


////
var arr = [1,[2,5,[3,[4]]]] as [Any]

var flatArr = [Int]()
func flatternArray(_ arr: [Any]) -> [Int] {
    
  
    
    for element in arr {
        if  element is Int {
            flatArr.append(element as! Int)
        }else {
            flatternArray(element as! [Any])
        }
      
    }

    
    
    return flatArr
}

