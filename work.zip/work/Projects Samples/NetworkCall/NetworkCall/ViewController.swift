//
//  ViewController.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 02/05/22.
//

import UIKit

class ViewController: UIViewController {

    let tableView = UITableView()
    var model : [Codable] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "KCELL")
        view.addSubview(tableView)
        tableView.delegate = self
        tableView.dataSource = self
       // fetchData()
        fetchTodoData()
        
 
        // Do any additional setup after loading the view.
    }


 
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        tableView.frame = self.view.bounds
        
    }
    
    
//    func fetchData () {
//        NetworkManager.shared.request(url: Constant.baseUrl, method: .GET, model: [User].self) { [weak self] results in
//            switch results {
//            case .success(let users):
//                DispatchQueue.main.async {
//                    self?.model = users
//                    self?.tableView.reloadData()
//                }
//            case .failure(let error):
//                print(error.localizedDescription)
//            }
//            
//        }
//        
//    }
//
//    
    func fetchTodoData () {
        NetworkManager.shared.request(url: Constant.todoListUrl, method: .GET, model: [TodoData].self) { [weak self] results in
            switch results {
            case .success(let users):
                DispatchQueue.main.async {
                    self?.model = users
                    self?.tableView.reloadData()
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
            
        }
        
    }
    
}

