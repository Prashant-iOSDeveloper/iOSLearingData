//
//  ViewController+tableView.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 02/05/22.
//

import Foundation
import UIKit


extension ViewController : UITableViewDelegate , UITableViewDataSource {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
        let cell = tableView.dequeueReusableCell(withIdentifier: "KCELL", for: indexPath)
        cell.textLabel?.text = (model[indexPath.row] as? Users)?.name
        cell.textLabel?.text = (model[indexPath.row] as? TodoData)?.title
        if let items = (model[indexPath.row] as? TodoData) {
            cell.accessoryType = items.completed ?? false ? .checkmark : .none
        }
        
        return cell
    }
    
    
    
    
}
