//
//  NetworkManager.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 02/05/22.
//

import Foundation

class NetworkManager {
    
    
    static let shared = NetworkManager()
    
    private init (){}
    
    
  private enum CustomError : Error {
        case invaildUrl
        case invaildData
        case unknown
    }
    
     enum Method : String {
        case GET
        case POST
    }
    
    
    func request <T : Codable>(url : URL?  , method : Method , model : T.Type , completion : @escaping (Result<T,Error>) -> Void) {
        
        guard let url = url else  {
            completion(.failure(CustomError.invaildUrl))
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, _, error in
            print("call1")
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                }else {
                    completion(.failure(CustomError.invaildData))
                }
                return
            }
            do {
                
                let result = try JSONDecoder().decode(model, from: data)
            
                completion(.success(result))
            }
            catch let error {
                completion(.failure(error))
            }
            
        }
        task.resume()
        
        print("call2")
    }
    
    
}

