//
//  Model.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 02/05/22.
//

import Foundation

struct Users : Codable {

    let name : String?
    let email : String?

}

struct TodoData : Codable {

    let title : String?
    let completed : Bool?

}


struct Constant {
    
    static let baseUrl = URL(string: "https://jsonplaceholder.typicode.com/users" )
    static let todoListUrl = URL(string: "https://jsonplaceholder.typicode.com/todos")
    
}
