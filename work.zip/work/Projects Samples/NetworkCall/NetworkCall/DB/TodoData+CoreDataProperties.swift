//
//  TodoData+CoreDataProperties.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 05/05/22.
//
//

import Foundation
import CoreData

//
//extension TodoData {
//
//    @nonobjc public class func fetchRequest() -> NSFetchRequest<TodoData> {
//        return NSFetchRequest<TodoData>(entityName: "TodoData")
//    }
//
//    @NSManaged public var name: String?
//    @NSManaged public var completed: Bool
//
//}
//
//extension TodoData : Identifiable {
//
//}
