//
//  User+CoreDataProperties.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 05/05/22.
//
//

import Foundation
import CoreData


//extension User {
//
//    @nonobjc public class func fetchRequest() -> NSFetchRequest<User> {
//        return NSFetchRequest<User>(entityName: "User")
//    }
//
//    @NSManaged public var name: String?
//    @NSManaged public var email: String?
//
//}
//
//extension User : Identifiable {
//
//}
