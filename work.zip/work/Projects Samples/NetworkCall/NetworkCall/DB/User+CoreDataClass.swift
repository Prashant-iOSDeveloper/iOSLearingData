//
//  User+CoreDataClass.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 05/05/22.
//
//

import Foundation
import CoreData

//@objc(User)
//public class User: NSManagedObject {
//
//}
