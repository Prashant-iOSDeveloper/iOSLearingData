//
//  TodoData+CoreDataClass.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 05/05/22.
//
//

import Foundation
import CoreData

//@objc(TodoData)
//public class TodoData: NSManagedObject {
//
//}
