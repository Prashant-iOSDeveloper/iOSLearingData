//
//  CoreDataManager.swift
//  NetworkCall
//
//  Created by Prashant Sharma on 02/05/22.
//

import Foundation
import CoreData


final class DBManager {
    
    private init () {}
    static let shared = DBManager()
  
// MARK: - Core Data stack

lazy var persistentContainer: NSPersistentContainer = {
   
    let container = NSPersistentContainer(name: "NetworkCall")
    container.loadPersistentStores(completionHandler: { (storeDescription, error) in
        if let error = error as NSError? {
           
            fatalError("Unresolved error \(error), \(error.userInfo)")
        }
    })
    return container
}()

// MARK: - Core Data Saving support
 
    lazy var context =  persistentContainer.viewContext
func saveContext () {
   
    if context.hasChanges {
        do {
            try context.save()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
}

}
