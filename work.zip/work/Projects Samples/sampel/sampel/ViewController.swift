//
//  ViewController.swift
//  sampel
//
//  Created by Prashant Sharma on 13/07/22.
//

import UIKit

class ViewController: UIViewController {
  unwoned let vc : ViewController1?
  
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let vc1 = ViewController1()
        vc1.vc =
        // Do any additional setup after loading the view.
    }


}

class ViewController1 : UIViewController {

    let vc : ViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

}

