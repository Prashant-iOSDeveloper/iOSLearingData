//
//  ViewController.swift
//  samplePro
//
//  Created by Prashant Sharma on 28/05/22.
//

import UIKit


struct Person {
    
    var name : String?
    var email : String?
}

protocol printvalue {
    
    func printvalue()
}

extension printvalue {
   func printvalue () {
        print("calledd")
    }
}


class ViewController: UIViewController , printvalue {

    var name : String?
   
     
    private var myname = "nams"
    
    let mainV : UIView = {
        let view1 = UIView()
        view1.backgroundColor = .red
        return view1
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
      
        let frame = CGRect(x: 20 , y: 50 , width: view.frame.width - 40, height: 200)
        
        mainV.frame = frame
       // mainV.center = view.center
        view.addSubview(mainV)
            // testAlphaWithBeta()
        
        let per = Problem()
        per.delta()
//        arr.filter { val in
//
//        }
//        var person1 = Person(name: "Prashant", email: "MyEmail@gmail.com")
//        var person2 = person1
//
//
//     //   let val : ( (_ completion : Result<Data , Error>) -> Void)?
//
//        let v = { (_ st : String ) in
//             print(st)
//        }
//
//        v("name")
//
//
//        numbers.map { num in
//           (num * 2)
//        }
//
//        print(numbers)
        
      //  callAddData()
        // Do any additional setup after loading the view.
    //    test()
//
//        var numbers = ""
        var str = 2
        var str1 = str
        var str2 = str1
        
        
        
        
        
        var arr   = [1,3,5,6,7,4,2]
   
        let num1  = arr
        var num2  = num1
        arr.append(3)
        
        print(arr)
        
       
        
       // arr = nil
       // arr = nil
       
        //print("c1 address: \(Unmanaged.passUnretained(c1).toOpaque())") //Is this correct ?
      //  num2.append(0)
     //   var num3 = num2
        print(MemoryAddress(of: &str))
        print(MemoryAddress(of: &str1))
        print(MemoryAddress(of: &str2))
        print(MemoryAddress(of: arr))
        print(MemoryAddress(of: num1))
        print(MemoryAddress(of: num2))
    
        struct Person   {
           // let name = ""
        }


        var person = Person()
        var person2 = person
        var person3 = person2
        print(MemoryAddress(of: &person))
        print(MemoryAddress(of: &person2))
        print(MemoryAddress(of: &person3))
//
//        withUnsafePointer(to: &person) { T in
//            print(T)
//        }
//        withUnsafePointer(to: &person3) { T in
//            print(T)
//        }
//        withUnsafePointer(to: &person2) { T in
//            print(T)
//        }
//        var intArr = [1, 7, 3, 6, 4]
       // sort(&intArr)
    }
    
    
    
    
    struct MemoryAddress<T>: CustomStringConvertible {
        let intValue: Int
        var description: String {
            let length = 2 + 2 * MemoryLayout<UnsafeRawPointer>.size
            return String(format: "%0\(length)p", intValue)
        }
        // for structures
        init(of structPointer: UnsafePointer<T>) {
            intValue = Int(bitPattern: structPointer)
        }
    }
   

    
    
    func sort<T : Comparable>(_ array: inout [T]) -> [T] {
      
        var i = 1
        
        while i < array.count {
            let x = array[i]
            var j = i - 1
            
            while j >= 0 && array[j] > x {
                array[j+1] = array[j]
                j -= 1
            }
            
            array[j+1] = x
            i += 1
            
        }
        

        return array
        
    }

    
    


    func test () {
        
        var closureArray: [() -> ()] = []
        var i = 0

        for _ in 1...5 {
            closureArray.append {
                print("value of i ---> \(i)")
            }
            i += 1
        }
        closureArray[0]()
        closureArray[4]()
    }
    
    func addData(numbersArray: [Int], completion: @escaping (Int) -> Void) {

        let sum = numbersArray.reduce(0, +)

        completion(sum)
    }


    func callAddData() {

        let array = [1, 2, 3]

        addData(numbersArray: array) { sum in
            print("2: Sum of the array is -> \(sum)")
        }

        print("1: Sum of the array is -> \(array.reduce(0, +))")

    }


    
    func higherOrderFunction<T>(_ arr : [T] , _odd : Bool?) -> [T] {
        
        var temp = arr
        
        func managefilterData() {
            
            for i in 0...temp.count - 1 {
                
                if (temp[i] as? Int ?? 0) % 2 == 0 {
                    print("")
                }
                
            }
        }
        
        return temp
    }

    
  
}


extension ViewController {
    
//
//    func printValue() {
//
//        self.myname = "change"
//        print(self.myname)
//
//    }
    
}


class Alpha {
    let b: Beta
    init(beta: Beta) {
        b = beta
    }
}

class Beta {
    let i: Int = 100
}

func testAlphaWithBeta() {
    let a = Alpha(beta: Beta())
    print(a.b.i)
}



class Problem {
    
    func delta () {
        let queue = DispatchQueue(label: "myqueue", qos: .background, attributes: .concurrent)
        DispatchQueue.main.async {
            print("X")
            self.charlie()
            print("Y")
        }
      //  queue.async {
            print("Z")
            self.charlie()
            print("A")
        //}
    }
    
    
    private func charlie (){
    var counter = 0
    for _ in 0..<100000 {
    counter += 1
        
    }
        
    }
    
    
    func printState() {
        print("A")

        DispatchQueue.main.async {
            print("B")

            DispatchQueue.main.async {
                print("C")
            
                DispatchQueue.main.async {
                    print("D")
                
                    DispatchQueue.global().sync {
                        print("E")
                    }
                }
            }

            DispatchQueue.global().sync {
                print("F")
            
                DispatchQueue.global().sync {
                    print("G")
                }
            }

            print("H")
        }

        print("I")
    }
    
}




extension Thread {
    var threadName: String {
        if isMainThread {
            return "main"
        } else if let threadName = Thread.current.name, !threadName.isEmpty {
            return threadName
        } else {
            return description
        }
    }
    
    var queueName: String {
        if let queueName = String(validatingUTF8: __dispatch_queue_get_label(nil)) {
            return queueName
        } else if let operationQueueName = OperationQueue.current?.name, !operationQueueName.isEmpty {
            return operationQueueName
        } else if let dispatchQueueName = OperationQueue.current?.underlyingQueue?.label, !dispatchQueueName.isEmpty {
            return dispatchQueueName
        } else {
            return "n/a"
        }
    }
}



