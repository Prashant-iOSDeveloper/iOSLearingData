//
//  listView.swift
//  TodoList
//
//  Created by Prashant Sharma on 21/08/22.
//

import SwiftUI

struct listView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct listView_Previews: PreviewProvider {
    static var previews: some View {
        listView()
    }
}
