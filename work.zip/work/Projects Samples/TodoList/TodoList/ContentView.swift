//
//  ContentView.swift
//  TodoList
//
//  Created by Prashant Sharma on 21/08/22.
//

import SwiftUI
import CoreData

struct ContentView: View {
 
    
    var body: some View {
        NavigationView {

            
            
            VStack(alignment: .leading, spacing: 10) {
                Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
                Text("Hello, World!")
                Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
                Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
                
            }
            
        .navigationTitle("Tasks")
    }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

