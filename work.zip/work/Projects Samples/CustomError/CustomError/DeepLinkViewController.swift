//
//  DeepLinkViewController.swift
//  CustomError
//
//  Created by Prashant Sharma on 11/04/22.
//

import UIKit
import StoreKit

class DeepLinkViewController: UIViewController , UITableViewDataSource , UITableViewDelegate {

    
    
    private let table = UITableView()
    private let data = ["Terms", "Privacy" , "Content"]
    public var name = "my"
    var second = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(table)
        table.register(UITableViewCell.self, forCellReuseIdentifier: "KCELL")
        table.dataSource = self
        table.delegate = self
        table.tableFooterView = createFooter()
        // Do any additional setup after loading the view.
    }
    

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        table.frame = self.view.bounds
        
    }
    
    
    private func createFooter() -> UIView {
        let footer = UIView(frame: CGRect(x: 0, y: 0, width: view.frame.size.width, height: 100))
        
        
        footer.backgroundColor = .secondarySystemBackground
        
        let size = (view.frame.size.width - 40)/3
        
        for x in 0..<3 {
            let button = UIButton(frame: CGRect(x: CGFloat(x) * size + (CGFloat(x) + 1 * 10) , y: 0, width: size, height: size))
            footer.addSubview(button)
            button.tag = x+1
            button.setImage(UIImage(named: "app\(x+1)"), for: .normal)
            button.imageView?.clipsToBounds = true
            button.addTarget(self, action: #selector(onTapButton), for: .touchUpInside)
        }
        
        return footer
    }
    
    private func openUrl (url : URL) {
        
        if UIApplication.shared.canOpenURL(url) {
            print("Deep link")
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
            
        }else {
            // app store // upcell
            let vc = SKStoreProductViewController()
            vc.loadProduct(withParameters: [SKStoreProductParameterITunesItemIdentifier : NSNumber(value: 915056765)], completionBlock: nil)
            present(vc, animated: true, completion: nil)
            
        }
        
    }//id586683407
    
    @objc private func onTapButton(_ sender : UIButton) {
     
        switch sender.tag {
        case 1:
            guard let url = URL(string: "ms-word://") else {
                return
            }
            openUrl(url: url)
            print("tapped applicaton \(sender.tag)")
        case 2:
            guard let url = URL(string: "ms-excel://") else {
                return
            }
            openUrl(url: url)
            print("tapped applicaton \(sender.tag)")
        case 3:
            print("tapped applicaton \(sender.tag)")
        default : break
        }
  
    }
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "KCELL", for: indexPath)
        
        cell.textLabel?.text = data[indexPath.row]
    
        return cell
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        data.count
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
