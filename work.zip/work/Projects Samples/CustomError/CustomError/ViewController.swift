//
//  ViewController.swift
//  CustomError
//
//  Created by Prashant Sharma on 28/03/22.
//

import UIKit

class ViewController: UIViewController {

    struct User : Codable {
        var name : String
    }
    
    enum UserFetchError : Error {
    case invalidUrl
    case unknown
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            try fetchUser { result in
                switch result {
                case .success(let users):
                    print(users.count)
                case .failure(let error):
                    print(error.localizedDescription)
                }
            }
        }
        catch {
            print(error)
        }
        let vc = DeepLinkViewController()
        print(vc.name , vc.second)
        
        sortArr(arr: [0, 1, 8, 3, 4, 4, 3, 6, 7, 11, 4, 5, 5, 8])
       
        // Do any additional setup after loading the view.
    }


    func fetchUser (completion : @escaping (Result<[User] , Error>) -> Void) throws  {
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/users") else {
            throw UserFetchError.invalidUrl
        }
        
        let task =  URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            if let error = error {
                completion(.failure(error))
            }else if let data = data {
                do {
                    let result = try JSONDecoder().decode([User].self, from: data)
                    completion(.success(result))
                }
                catch {
                    completion(.failure(error))
                }
            }else {
                completion(.failure(UserFetchError.unknown))
            }
        }
        task.resume()
    }
    
    
    func sortArr( arr : [Int]) -> [Int] {
        
        
        var temp = arr
        for j in 0..<temp.count - 1 {
        for i in 0..<temp.count - 1 {
            print(i)
            if temp[i] > temp[i+1] {
                
                let val = temp[i]
                temp[i] = temp[i+1]
                temp[i+1] = val
            }
        }
        }
        print(temp)
        return temp
        
    }

    
    
}

