//
//  UserViewController.swift
//  CustomError
//
//  Created by Prashant Sharma on 29/03/22.
//

import UIKit

class UserViewController: ViewController  {
  
    
   
    

    let table = UITableView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
    }
    


}
