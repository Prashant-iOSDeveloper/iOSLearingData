//
//  FirebaseManager.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 11/07/22.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseStorage
import SwiftUI
import FirebaseFirestore

class FirebaseManager : NSObject {
    
    let auth : Auth
    let storage : Storage
    let firestore : Firestore
    var currentUser: UserChat?
    static let shared  = FirebaseManager()
    
    override init () {
        
        FirebaseApp.configure()
        self.auth = Auth.auth()
        self.storage = Storage.storage()
        self.firestore = Firestore.firestore()
        super.init()
        
    }
 
    
    
    
}

