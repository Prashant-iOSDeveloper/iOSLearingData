//
//  FirebaseConstant.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 18/07/22.
//

import Foundation

struct FirebaseConstants {
    static let fromId = "fromId"
    static let recevierUserID = "recevierUserID"
    static let text = "text"
    static let timestamp = "timestamp"
    static let email = "email"
    static let uid = "uid"
    static let profile_picture = "profilePicture"
    static let messages = "messages"
    static let users = "Users"
    static let recentMessages = "recent_message"
}
