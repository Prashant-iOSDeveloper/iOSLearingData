//
//  UserChatModel.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 12/07/22.
//

import Foundation
import FirebaseFirestoreSwift

struct UserChat :  Codable , Identifiable {
    
   @DocumentID var id : String?
    let uid , email , profilePicture : String
 
    
}
