//
//  RecentMessagesModel.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 18/07/22.
//

import Foundation
import FirebaseFirestoreSwift

struct RecentMessage  : Identifiable , Codable {
    
    @DocumentID var id: String?
    
    let text , fromId , recevierUserID : String
    let email , profilePicture : String
    var timestamp :  Date
    
    var userName : String {
        email.components(separatedBy: "@").first ?? email
    }
    
    var timeAgo : String {
        
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: timestamp, relativeTo: Date())
        
    }

}
