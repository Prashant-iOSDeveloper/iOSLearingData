//
//  ChatMessageModel.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 18/07/22.
//

import Foundation
import FirebaseFirestoreSwift
import UIKit

struct ChatMessageModel : Identifiable , Codable {
  @DocumentID var id: String?
    
    let fromId , recevierUserID , text : String
    let image : Data?
    let timestamp : Date
    
}
