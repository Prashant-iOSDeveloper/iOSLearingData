//
//  MainMessageView.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 12/07/22.
//

import SwiftUI
import SDWebImage
import SDWebImageSwiftUI
import Firebase



struct MainMessageView: View {
    
    @State var logoutOption = false
    @State var shouldNavigatetoChatView = false
    @ObservedObject private var messageViewmodel = MainMessageViewModel()
    private var chatLogViewModel = ChatViewModel(chatUser: nil)
    @State var chatUser : UserChat?
    
    var body: some View {

        NavigationView{
            VStack {
                // custom nav bar
             //   Text("CURRENT USER ID : \(messageViewmodel.charUser?.uid ?? "")")
                customNavBar
                messagesView
                NavigationLink("", isActive: $shouldNavigatetoChatView) {
                    ChatView(vm: chatLogViewModel)
                }

            }
            .overlay(
                newMessageButton,alignment: .bottom)
            .navigationBarHidden(true)
        }
        
    }
    
    
    private var customNavBar : some View {
        
        HStack (spacing : 16){
            
            WebImage(url: URL(string: messageViewmodel.chatUser?.profilePicture ?? ""))
                .resizable()
                .scaledToFill()
                .frame(width: 50.0, height: 50.0)
                .clipped()
                .cornerRadius(50)
                .overlay(RoundedRectangle(cornerRadius: 50)
                    .stroke(Color(.label),lineWidth: 1))
                .shadow(radius: 10)
           
            VStack(alignment: .leading, spacing: 4) {
                let email = (messageViewmodel.chatUser?.email ?? "").lowercased().replacingOccurrences(of: "@gmail.com", with: "").uppercased()
                Text("\(email)")
                        .font(.system(size : 24 , weight : .bold))
                HStack {
                    Circle()
                        .foregroundColor(.green)
                        .frame(width: 14.0, height: 14.0)
                    Text("online")
                        .font(.system(size : 14))
                        .foregroundColor(Color(.lightGray))
                }
                
            }
       
              Spacer()
            Button {
                logoutOption.toggle()
            } label: {
                Image(systemName: "gear")
                     .font(.system(size: 24, weight : .bold))
                     .foregroundColor(.black)
            }
        }
            .padding()
            .actionSheet(isPresented: $logoutOption) {
                .init(title: Text("Settings"), message: Text("What do you want to do?"), buttons: [
                    .destructive(Text("Sign Out"), action: {
                        print("handle signout here")
                        messageViewmodel.handleSignOut()
                    }),
                 //   .default(Text("Log Out")),
                    .cancel()
                        
                ])
            }
            .fullScreenCover(isPresented: $messageViewmodel.isUserCurrentlyLoggedOut, onDismiss: nil) {
              //  Text("Cover")
                LoginView(didCompleteLogin: {
                    self.messageViewmodel.isUserCurrentlyLoggedOut = false
                    self.messageViewmodel.fetchCurrentUser()
                    self.messageViewmodel.fetchRecentMessage()
                })
            }

         
    }
   
    
    
    private var messagesView: some View {
        ScrollView {
            ForEach(messageViewmodel.receentMessageArr) { recentMessage in
                VStack {
                    Button {
                        let uid = FirebaseManager.shared.auth.currentUser?.uid == recentMessage.fromId ? recentMessage.recevierUserID : recentMessage.fromId
                        
                        self.chatUser = .init(id: uid, uid: uid, email: recentMessage.email, profilePicture: recentMessage.profilePicture)
                        
                        self.chatLogViewModel.chatUser = self.chatUser
                        self.chatLogViewModel.fetchMessages()
                        self.shouldNavigatetoChatView.toggle()
                    } label: {
                        HStack(spacing: 16) {
                            WebImage(url: URL(string: recentMessage.profilePicture))
                                .resizable()
                                .scaledToFill()
                                .frame(width: 64, height: 64)
                                .clipped()
                                .cornerRadius(64)
                                .overlay(RoundedRectangle(cornerRadius: 64)
                                            .stroke(Color.black, lineWidth: 1))
                                .shadow(radius: 5)
                            
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Text(recentMessage.userName)
                                    .font(.system(size: 16, weight: .bold))
                                    .foregroundColor(Color(.label))
                                    .multilineTextAlignment(.leading)
                                Text(recentMessage.text)
                                    .font(.system(size: 14))
                                    .foregroundColor(Color(.darkGray))
                                    .multilineTextAlignment(.leading)
                            }
                            Spacer()
                            
                            Text(recentMessage.timeAgo)
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundColor(Color(.label))
                        }
                    }


                    
                    Divider()
                        .padding(.vertical, 8)
                }.padding(.horizontal)
                
            }.padding(.bottom, 50)
        }
    }
    @State var isNesMessageButtonTapped = false
    
    private var newMessageButton : some View {
        Button {
            isNesMessageButtonTapped.toggle()
        } label: {
            HStack {
                Spacer()
                Text("+ New message")
                    .font(.system(size: 16 , weight: .bold))
                Spacer()
            }
            .padding(.vertical)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(32)
            .padding(.horizontal)
            .shadow(radius: 15)
           
        }
        
        .fullScreenCover(isPresented: $isNesMessageButtonTapped, onDismiss: nil) {
            AddNewUserView(didSelectNewUser: { user in
                self.shouldNavigatetoChatView.toggle()
                self.chatUser = user
                self.chatLogViewModel.chatUser = user
                self.chatLogViewModel.fetchMessages()
            
            })
        }
    }
    
}

struct MainMessageView_Previews: PreviewProvider {
    static var previews: some View {
        MainMessageView()
            .preferredColorScheme(.light)
        
        MainMessageView()
          
    }
    
}
