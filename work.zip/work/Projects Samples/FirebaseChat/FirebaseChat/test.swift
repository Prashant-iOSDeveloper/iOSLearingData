//
//  test.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 16/07/22.
//

import SwiftUI

struct test: View {
    var body: some View {
        
        ScrollView {
  
                ForEach (0..<10) { num in
                    VStack{
                        HStack(spacing : 7) {
                         
                        Image(systemName: "person.fill")
                            .font(.system(size: 30))
                            .foregroundColor(.red)
                            .padding()
                        Text("Hello, World!")
                            .font(.system(size: 20))
                            Spacer()
                        }
                
                      
                
                    }
                   
                
                
            }
            
        }
        
       
    }
}

struct test_Previews: PreviewProvider {
    static var previews: some View {
        test()
    }
}
