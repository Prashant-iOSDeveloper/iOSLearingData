//
//  ChatView.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 14/07/22.
//

import SwiftUI
import Firebase


class ChatViewModel : ObservableObject {
    
    @Published var chatMesage = ""
    @Published var chatMessages = [ChatMessageModel]()

    
    var chatUser : UserChat?
    init (chatUser : UserChat?) {
        self.chatUser = chatUser
        fetchMessages()
    }
    
    var firestoreListener: ListenerRegistration?
    
    func fetchMessages() {
        guard let fromID = FirebaseManager.shared.auth.currentUser?.uid else { return}
        guard let recevierUserID = chatUser?.uid else {return}
        
        firestoreListener?.remove()
        chatMessages.removeAll()
        
        firestoreListener = FirebaseManager.shared.firestore
            .collection(FirebaseConstants.messages)
            .document(fromID)
            .collection(recevierUserID)
            .order(by: FirebaseConstants.timestamp)
            .addSnapshotListener { querySnapshot, err in
                if let error = err {
                    print(error)
                    return
                }
                querySnapshot?.documentChanges.forEach({ documentChange in
                    if documentChange.type == .added {
                        
                        
//                        let docID = documentChange.document.documentID
                        
                        do {
                            if  let chatMessage =  try? documentChange.document.data(as: ChatMessageModel.self) {
                            self.chatMessages.append(chatMessage)
                            }
                        }
                        
                       // self.chatMessages.append(.init(documentID: docID, data: data))
                    }
                })
                DispatchQueue.main.async {
                    self.count += 1
                }
              
//                querySnapshot?.documents.forEach({ queryDocumentSnapshot in
//
//                   let messageData =  queryDocumentSnapshot.data()
//
//                })
                
                
            }
        
    }
    
    func handleSend(_ image : UIImage? = nil) {
        
        guard let fromId = FirebaseManager.shared.auth.currentUser?.uid else { return}
    
        guard let recevierUserID = chatUser?.uid else {return}
        
       let document = FirebaseManager.shared.firestore.collection(FirebaseConstants.messages)
            .document(fromId)
            .collection(recevierUserID)
            .document()
        let imageData : Data?
        if image != nil {
           //  imageData = self.image?.jpegData(compressionQuality: 0.5)
        }
        
        let msg = ChatMessageModel(id: nil, fromId: fromId, recevierUserID: recevierUserID, text: chatMesage, image: nil, timestamp: Date())
    
        try? document.setData(from : msg) { err in
            if let error = err {
                print(error)
                return
            }
          
            print("current user sending")
            self.persitRecentMessage()
            self.chatMesage = ""
            self.count += 1
        }
        
        
        let recipientDocument = FirebaseManager.shared.firestore.collection(FirebaseConstants.messages)
             .document(recevierUserID)
             .collection(fromId)
             .document()
        
       try? recipientDocument.setData(from : msg) { err in
            if let error = err {
                print(error)
                return
            }
            print("receiver user sending")
    }
      
    
    }
    
    @Published var count = 0
    
  private func  persitRecentMessage() {
        
      guard let uid = FirebaseManager.shared.auth.currentUser?.uid else { return }
      guard let toId = chatUser?.uid else {return}
      let document = FirebaseManager.shared.firestore.collection(FirebaseConstants.recentMessages)
          .document(uid)
          .collection(FirebaseConstants.messages)
          .document(toId)
      
      
      let data = [FirebaseConstants.timestamp : Timestamp(),
                  FirebaseConstants.fromId : uid ,
                  FirebaseConstants.recevierUserID : toId ,
                  FirebaseConstants.text : self.chatMesage,
                  FirebaseConstants.email : chatUser?.email ?? "" ,
                  FirebaseConstants.profile_picture : chatUser?.profilePicture ?? "" ]
                  as [String : Any]
      
      document.setData(data) { error in
          if let error = error {
              print(error.localizedDescription)
              return
          }
          
      }
      
     let  recipientDocument = FirebaseManager.shared.firestore.collection(FirebaseConstants.recentMessages)
          .document(toId)
          .collection(FirebaseConstants.messages)
          .document(uid)
      let recipientdata = [FirebaseConstants.timestamp : Timestamp(),
                  FirebaseConstants.fromId : toId ,
                  FirebaseConstants.recevierUserID : uid ,
                  FirebaseConstants.text : self.chatMesage,
        FirebaseConstants.email : FirebaseManager.shared.currentUser?.email ?? "",
                           FirebaseConstants.profile_picture : FirebaseManager.shared.currentUser?.profilePicture ?? "" ]
                  as [String : Any]
      recipientDocument.setData(recipientdata) { error in
          if let error = error {
              print(error.localizedDescription)
              return
          }
          
      }
    }
    
}


struct ChatView: View {
//
//    let chatUser : UserChat?
//
//    init (chatUser : UserChat?) {
//        self.chatUser = chatUser
//        self.vm = .init(chatUser: chatUser)
//    }
    
    @State var shouldShowImagePicker = false
    @State var image : UIImage?
    
    @ObservedObject var vm : ChatViewModel

    var body: some View {
        VStack {
            
            messageView
            chatBottomBar
        }
        .navigationTitle(vm.chatUser?.email ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear {
            vm.firestoreListener?.remove()
        }
//        .navigationBarItems(trailing: Button(action: {
//            vm.count += 1
//        }, label: {
//            Text("Count : \(vm.count)")
//        }))
        
    }
    
    private var messageView : some View {
        ScrollView {
            ScrollViewReader { scrollViewProxy in
                
                VStack {
                    ForEach(vm.chatMessages) { message in
                        MessageView(message: message)
                    }
                    HStack { Spacer() }
                            .id("empty")
                    
                        }
                .onReceive(vm.$count) { _ in
                    withAnimation (.easeInOut(duration: 0.5)){
                        scrollViewProxy.scrollTo("empty" , anchor: .bottom)
                }
                
                
                
                }
            }
           
        }
        .background(Color(.init(white: 0.95, alpha: 1)))
       
        
    }
    
    
    
    private var chatBottomBar: some View {
        HStack(spacing: 16) {
            
            Button {
                shouldShowImagePicker.toggle()
                
            } label: {
                Image(systemName: "photo.on.rectangle")
                    .font(.system(size: 24))
                    .foregroundColor(Color(.darkGray))
            }
            ZStack {
                DescriptionPlaceholder()
                TextEditor(text: $vm.chatMesage)
                    .opacity(vm.chatMesage.isEmpty ? 0.5 : 1)
            }
            .frame(height: 40)
            
            Button {
                vm.handleSend()
            } label: {
                Text("Send")
                    .foregroundColor(.white)
            }
            .padding(.horizontal)
            .padding(.vertical, 8)
            .background(Color.blue)
            .cornerRadius(4)
        }
        .padding(.horizontal)
        .padding(.vertical, 8)
        .fullScreenCover(isPresented: $shouldShowImagePicker, onDismiss: nil) {
            ImagePicker(image: $image)
        }
        
        
        
    }
   

    
    private var chatBottomView : some View {
        HStack(spacing : 16) {
            Image(systemName: "photo.on.rectangle")
                .font(.system(size: 24))
                .foregroundColor(Color(.darkGray))
            DescriptionPlaceholder()
            TextEditor(text: $vm.chatMesage)
                .opacity(vm.chatMesage.isEmpty ? 0.5 : 1)
                .frame(height: 40)
            Button {
                vm.handleSend()
            
            } label: {
                Text("Send")
                    .foregroundColor(.white)
            }
            .padding(.horizontal)
            .padding(.vertical , 8)
            .background(.blue)
            .cornerRadius(4)
 
        }
        .padding(.horizontal)
        .padding(.vertical , 8)
    }
    
}

struct MessageView : View {
    
    let message : ChatMessageModel
    var body: some View {
        VStack {
        if message.fromId == FirebaseManager.shared.auth.currentUser?.uid {
            HStack {
            Spacer()
            HStack {
                Text (message.text)
             .foregroundColor(.white)
            }
            .padding()
            .background(.blue)
            .cornerRadius(8)
           
                
                
        }
        } else {
            HStack {
            HStack {
                Text (message.text)
             .foregroundColor(.black)
            }
                
            .padding()
            .background(.white)
            .cornerRadius(8)
                Spacer()
        }
            
        }
              
        }
        .padding(.horizontal)
        .padding(.top , 8)
    }
    
}
    
    private struct DescriptionPlaceholder: View {
        var body: some View {
            HStack {
                Text("Description")
                    .foregroundColor(Color(.gray))
                    .font(.system(size: 17))
                    .padding(.leading, 5)
                    .padding(.top, -4)
                Spacer()
            }
        }
    }
   


struct ChatView_Previews: PreviewProvider {
    static var previews: some View {
        MainMessageView()
        //        NavigationView {
        //            ChatLogView(chatUser: .init(data: ["uid": "R8ZrxIT4uRZMVZeWwWeQWPI5zUE3", "email": "waterfall1@gmail.com"]))
        //        }
        
    }
}
