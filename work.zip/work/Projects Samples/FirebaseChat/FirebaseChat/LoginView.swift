//
//  ContentView.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 11/07/22.
//

import SwiftUI
import CoreData
import Firebase


struct LoginView: View {
    
    let didCompleteLogin : () -> ()
    @State private var isLogin = false
    @State private var email = ""
    @State private var password = ""
    @State private var shouldShowImagePicker = false
    
    var body: some View {
        
        
        NavigationView {
            ScrollView {
                VStack(spacing : 20) {
                    Picker("test", selection: $isLogin) {
                        Text("Login")
                            .tag(true)
                        Text("Create acount")
                            .tag(false)
                    }.pickerStyle(.segmented)
                    if !isLogin {
                        Button {
                            shouldShowImagePicker.toggle()
                        } label: {
                            VStack {
                                
                                if let image = self.image {
                                   Image(uiImage: image)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 120, height: 120)
                                        .cornerRadius(90)
                                }else {
                                    Image(systemName: "person.fill")
                                        .font(.system(size: 65))
                                        .padding()
                                        .foregroundColor(Color(.label))
                                }
                            }
                            .overlay(RoundedRectangle(cornerRadius: 64)
                                .stroke(Color.black, lineWidth: 2))
                        }
                    }
                    
                    Group {
                        TextField("Email", text: $email)
                            .keyboardType(.emailAddress)
                            .autocapitalization(.none)
                        SecureField("Password", text: $password)
                        
                    }
                    .padding(12)
                    .background(.white)
                    
         
                    Button {
                        if isLogin {
                            loginAcount()
                        }else {
                            handleAction()
                        }
                      
                    } label: {
                        HStack {
                            Spacer()
                            Text(isLogin ? "Log In" : "Create acount")
                                .foregroundColor(.white)
                                .padding(.vertical ,10)
                            Spacer()
                            
                        }.background(.blue)
                        
                    }
                    Text(self.loginErrorMessage)
                        .foregroundColor(.red)
                        
                    
                }.padding()
                
                
            }
            .navigationTitle(isLogin ? "Log In" : "Create Acount")
            .background(Color(.init(white: 0, alpha: 0.05))
                .ignoresSafeArea())
            .fullScreenCover(isPresented: $shouldShowImagePicker, onDismiss: nil) {
                ImagePicker(image: $image)
            }
        }
        .navigationViewStyle(.stack)
                
    }
    @State var image : UIImage?
    
    private func handleAction() {
        if isLogin {
            
        }else {
            createUserAcount()
        }
       
    }
    
    @State var loginErrorMessage = ""
    private func createUserAcount() {
        if self.image == nil {
            self.loginErrorMessage = "You must select the avatar image"
            return
        }
        
        FirebaseManager.shared.auth.createUser(withEmail: email, password: password) { result, err in
            if let error = err {
                loginErrorMessage = "(Error : \(error.localizedDescription))"
                return
            }
            loginErrorMessage = "(Success Created User: \(result?.user.uid ?? ""))"
            
            presistImageToStorage()
           
        }
        
    }
    
    private func loginAcount() {
        
        FirebaseManager.shared.auth.signIn(withEmail: email, password: password) { result, err in
            if let error = err {
                loginErrorMessage = "(Login Error : \(error.localizedDescription))"
                return
            }
            loginErrorMessage = "(Login Success : \(result?.user.uid ?? ""))"
            self.didCompleteLogin()
            
        }
        
    }
    
    private func presistImageToStorage() {
      //  let fileName = UUID().uuidString
        guard let uid = FirebaseManager.shared.auth.currentUser?.uid else { return }
        let ref =  FirebaseManager.shared.storage.reference(withPath: uid)
        guard let imageData = self.image?.jpegData(compressionQuality: 0.5) else { return }
        
        ref.putData(imageData) { metadata , err in
            if let err = err {
                print(err)
                self.loginErrorMessage = "Failed to push image to storage : \(err)"
                return
            }
            
            ref.downloadURL { url, err in
                if let err = err {
                    self.loginErrorMessage = "Failed to download image from storage : \(err)"
                    return
                }
                self.loginErrorMessage = "Successfully stored user image with url \(url?.absoluteString ?? "")"
                guard let url = url else {return}
                self.storeUserInformation(url)
                
                
            }
        }
        
    }
    private func storeUserInformation (_ imageProfileurl : URL) {
        guard let uid = FirebaseManager.shared.auth.currentUser?.uid else {return}
        let userData = [FirebaseConstants.email: self.email, FirebaseConstants.uid: uid, FirebaseConstants.profile_picture : imageProfileurl.absoluteString]
        
        
        
        FirebaseManager.shared.firestore.collection(FirebaseConstants.users)
            .document(uid).setData(userData) { err in
                if let err = err {
                    self.loginErrorMessage = "\(err)"
                    return
                }
                print("Z")
            }
        self.didCompleteLogin()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(didCompleteLogin: {
            
        }).environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
