//
//  AddNewUserView.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 13/07/22.
//

import SwiftUI
import Combine
import SDWebImageSwiftUI

class CreateNewMessageVM : ObservableObject  {
    
    @Published var user = [UserChat]()
    @Published var errorMessage = " some"
    
    
    init () {
        fetchUser()
    }
    
   private func fetchUser() {
       FirebaseManager.shared.firestore.collection("Users").getDocuments { [weak self] documentSnapshot, err in
           if let error = err {
               print("error")
               self?.errorMessage = "Error fetching all Users: \(error)"
               return
           }
           
           documentSnapshot?.documents .forEach({ snapshop in
               do {
                   if  let userChatData = try?  snapshop.data(as: UserChat.self) {
                       let curretUserUid = userChatData.uid
                   if curretUserUid != FirebaseManager.shared.auth.currentUser?.uid {
                   self?.user.append(userChatData)
                   }
                   }
               }
              
              
           })
           
           self?.errorMessage = "fetch user successfully "
       }
    }
    
}


struct AddNewUserView: View {
    
    
    let didSelectNewUser : (UserChat) -> ()
    
    @ObservedObject var vm = CreateNewMessageVM()
    @Environment(\.presentationMode) var presentedMode
    
    var body: some View {
        
        NavigationView {
        ScrollView {
            ForEach(vm.user) { obj in
                
                Button {
                didSelectNewUser(obj)
                    presentedMode.wrappedValue.dismiss()
                    
                } label: {
                    HStack(spacing : 15) {
                    WebImage(url: URL(string: obj.profilePicture)).resizable()
                        .scaledToFill()
                        .frame(width: 60.0, height: 60.0)
                        .clipped()
                        .cornerRadius(50)
                        .overlay(RoundedRectangle(cornerRadius: 50)
                            .stroke(Color(.label),lineWidth: 1))
                        .shadow(radius: 10)
                    Text(obj.email)
                        .font(.system(size: 18))
                        .foregroundColor(Color(.label))
                Spacer()
                       
                }.padding(.horizontal)
                Divider()
                .padding(.vertical , 8)
                }

                
           
        }
        }
        .navigationTitle("New Message")
        .toolbar {
            ToolbarItemGroup(placement: .navigationBarLeading) {
                Button(action: {
                    presentedMode.wrappedValue.dismiss()
                }, label: {
                    Text("Cancel")
                     
                })
               
            }
        }
        }
        
       
    }
}

struct AddNewUserView_Previews: PreviewProvider {
    static var previews: some View {
        // AddNewUserView(didSelectNewUser: <#(UserChat) -> ()#>)
        
        MainMessageView()
    }
}
