//
//  FirebaseChatApp.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 11/07/22.
//

import SwiftUI

@main
struct FirebaseChatApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
           // LoginView()
            MainMessageView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
