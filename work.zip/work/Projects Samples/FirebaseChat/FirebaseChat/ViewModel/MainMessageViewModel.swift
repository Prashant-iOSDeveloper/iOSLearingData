//
//  MainMessageViewMiodel.swift
//  FirebaseChat
//
//  Created by Prashant Sharma on 12/07/22.
//

import Foundation
import FirebaseFirestoreSwift
import Firebase

class MainMessageViewModel : ObservableObject {
    
    @Published var errorMessage = ""
    @Published var chatUser : UserChat?
    @Published var isUserCurrentlyLoggedOut = false
    private var firestoreListener: ListenerRegistration?
    @Published var receentMessageArr = [RecentMessage]()
    init() {
        DispatchQueue.main.async {
            self.isUserCurrentlyLoggedOut = FirebaseManager.shared.auth.currentUser?.uid == nil
        }
        
        fetchCurrentUser()
        fetchRecentMessage()
        
    }
    
    
    
     func fetchRecentMessage() {
        
        guard let uid = FirebaseManager.shared.auth.currentUser?.uid else {return}
        
        firestoreListener?.remove()
        self.receentMessageArr.removeAll()
        
         firestoreListener =  FirebaseManager.shared.firestore.collection(FirebaseConstants.recentMessages)
            .document(uid)
            .collection(FirebaseConstants.messages)
            .order(by: FirebaseConstants.timestamp)
            .addSnapshotListener { querySnapshot, error in
                if let error = error {
                    print(error)
                    return
                }
                querySnapshot?.documentChanges.forEach({ documentChange in
                    // if documentChange.type == .modified {
                    let docId = documentChange.document.documentID
                    if let index = self.receentMessageArr.firstIndex(where: { rm in
                        return rm.id == docId
                    }) {
                        self.receentMessageArr.remove(at: index)
                    }
                    
                    do {
                        if let rm = try? documentChange.document.data(as: RecentMessage.self) {
                            self.receentMessageArr.insert(rm, at: 0)
                        }
                    }
                    
                    //                    self.receentMessageArr.insert(RecentMessage(docId, data: documentChange.document.data()), at: 0)
                    // }
                    
                })
                
            }
        
    }
     
    func fetchCurrentUser()  {
        guard  let uid =  FirebaseManager.shared.auth.currentUser?.uid else {
            self.errorMessage = "not able to login with user"
            return
            
        }
        //  self.errorMessage = "\(uid)"
        FirebaseManager.shared.firestore.collection("Users").document(uid).getDocument { snapshot, err in
            if let error = err {
                print("failed to fetch current user \(error)")
                self.errorMessage =  "failed to fetch current user \(error)"
                return
            }
            
         
            
            self.chatUser = try? snapshot?.data(as: UserChat.self)
            FirebaseManager.shared.currentUser = self.chatUser
        }
        
        
    }
    
    
    
    func handleSignOut() {
        isUserCurrentlyLoggedOut.toggle()
        try? FirebaseManager.shared.auth.signOut()
        
        
    }
    
}   
