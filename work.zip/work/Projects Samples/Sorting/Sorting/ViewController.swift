//
//  ViewController.swift
//  Sorting
//
//  Created by Prashant Sharma on 09/08/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        var myArr = [3,5,2,6,0,10,12,9,8]
        var strARr = ["r","ee","a","z"]
        
    //   print( myArr.selectionSort())
        
        print(sorting(input: myArr))
         // Do any additional setup after loading the view.
    }
    
    
    func mergeSort (_ input :  [Int]) -> [Int] {
        let arr  = input
        let middleIndex = arr.count / 2
        guard arr.count > 1 else {
            return arr
        }
        var leftArr = Array(arr[0..<middleIndex])
        var rightArr = Array(arr[middleIndex..<arr.count])
        
        return merge(mergeSort(leftArr), mergeSort(rightArr))
        
    }
    
    func merge(_ left :  [Int] , _ right :  [Int]) ->  [Int] {
        
        var mergedArr = [Int]()
        var leftArr = left
        var rightArr = right
        
        if leftArr.first! < rightArr.first! {
            mergedArr.append( leftArr.removeFirst())
        }else  {
            mergedArr.append( rightArr.removeFirst())
        }
        return mergedArr + leftArr + rightArr
    }
    
    
    

    func quickSort (_ inputArr : [Int]) -> [Int] {
        
        let arr = inputArr
        var lessArr = [Int]()
        var equalArr = [Int]()
        var greaterArr = [Int]()
        
       guard  arr.count > 1 else{
            return arr
        }
    
        let value  = arr[0]
        for item in arr {
            
            if item < value {
                lessArr.append(item)
            }
            if item > value {
                greaterArr.append(item)
            }
            if item  == value {
                equalArr.append(item)
            }
        }
   
        return (quickSort(lessArr) + equalArr + quickSort(greaterArr))
    }
    
    

        
      
    
}



extension Array where Element :  Comparable {
  
    
    func bubbleSort () -> [Element] { // n*2
        var arr = self
        for _ in 0..<arr.count - 1 {
            for j in 0..<arr.count - 1  {
                if arr[j] > arr [j+1] {
                    let temp = arr[j]
                    arr[j] = arr[j+1]
                    arr[j+1] = temp
                }
            }
            
        }
        return arr
    }
    
    
    func insertionSort () -> [Element]{ // n*2
        var arr = self
        var i = 1
        while i < arr.count {
            
            var j = i - 1
            let x = arr[i]
         
            while j >= 0 && arr[j] > x {
                arr[j+1] = arr[j]
               
                j -= 1
            }
            arr[j+1] = x
            i += 1
        }
        return arr
    }
   
  
    
    
    func selectionSort () -> [Element] { // n*2
        var arr = self
        let count = self.count
        
        for i in 0..<count  {
            
            var minNum = arr[i] ,  minIndex = i
            
            for j in i+1..<count {
                if arr[j] < minNum {
                   minNum = arr[j]
                    minIndex = j
                }
            }
            let temp = arr[i]
            arr[i] = arr[minIndex]
            arr[minIndex] = temp
        }
        
        return arr
    }
    
//
//   mutating func mergeSort(_ obj : [Element]) -> [Element] {
//
//        var arr = obj
//
//        guard arr.count > 1 else {
//            return arr
//        }
//
//        var left = Array(arr[0..<arr.count / 2])
//        var right = Array(arr[(arr.count/2)..<arr.count])
//
//
//        return merge(left: &mergeSort(left), right: &mergeSort(right))
//    }
//
//    func merge( left : inout [Element] , right : inout [Element]) -> [Element] {
//
//        var mergedArr = [Element]()
//
//        if left.first! < right.first! {
//
//            mergedArr.append(left.removeFirst())
//        } else {
//            mergedArr.append(right.removeFirst())
//        }
//        return mergedArr + left + right
//    }
   
    
   
    
}
// quick sort
func sorting(input : [Int]) -> [Int] {
    
    var lesserArr = [Int]()
    var greaterArr = [Int]()
    var equalArr = [Int]()
    
  
    
    guard input.count > 1 else {
         return input
     }
    var number = input[0]
    for i in 0..<input.count {
        
        if input[i] < number {
            lesserArr.append(input[i])
        }
        if input[i] > number {
            greaterArr.append(input[i])
        }
        if input[i] == number {
            equalArr.append(input[i])
        }
        
    }
    
    
    
    
    return (sorting(input: lesserArr) + equalArr + sorting(input: greaterArr))
}
