//
//  Login+CoreDataProperties.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//
//

import Foundation
import CoreData


extension Login {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Login> {
        return NSFetchRequest<Login>(entityName: "Login")
    }

    @NSManaged public var email: String?
    @NSManaged public var access: String?
    @NSManaged public var id: Int64
    @NSManaged public var first_name: String?
    @NSManaged public var last_name: String?

}

extension Login : Identifiable {

}
