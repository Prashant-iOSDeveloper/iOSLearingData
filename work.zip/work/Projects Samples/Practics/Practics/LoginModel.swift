//
//  LoginModel.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import Foundation


struct LoginModel : Codable {
    let access : String?
    let refresh : String?
    let user : User?
    var error : Error? = nil
    
    enum CodingKeys: String, CodingKey {

        case access = "access"
        case refresh = "refresh"
        case user = "user"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        access = try values.decodeIfPresent(String.self, forKey: .access)
        refresh = try values.decodeIfPresent(String.self, forKey: .refresh)
        user = try values.decodeIfPresent(User.self, forKey: .user)
    }

}


struct User : Codable {
    let id : Int?
    let first_name : String?
    let last_name : String?
    let email : String?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case first_name = "first_name"
        case last_name = "last_name"
        case email = "email"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        first_name = try values.decodeIfPresent(String.self, forKey: .first_name)
        last_name = try values.decodeIfPresent(String.self, forKey: .last_name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
    }

}

