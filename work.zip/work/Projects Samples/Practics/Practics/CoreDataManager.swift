//
//  CoreDataManager.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import Foundation
import CoreData


final class DBManager {
    
    private init () {}
    static let shared = DBManager()
  
// MARK: - Core Data stack

lazy var persistentContainer: NSPersistentContainer = {
   
    let container = NSPersistentContainer(name: "Practics")
    container.loadPersistentStores(completionHandler: { (storeDescription, error) in
        if let error = error as NSError? {
           
            fatalError("Unresolved error \(error), \(error.userInfo)")
        }
    })
    return container
}()

// MARK: - Core Data Saving support
 
 lazy var context =  persistentContainer.viewContext
    
  func saveContext () {
   
    if context.hasChanges {
        do {
            try context.save()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
    }
}
    
    func deleteAllData(_ entity:String) {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entity)
        fetchRequest.returnsObjectsAsFaults = false
        do {
            let results = try context.fetch(fetchRequest)
            for object in results {
                guard let objectData = object as? NSManagedObject else {continue}
                context.delete(objectData)
            }
        } catch let error {
            print("Detele all data in \(entity) error :", error)
        }
    }
    
    
}
