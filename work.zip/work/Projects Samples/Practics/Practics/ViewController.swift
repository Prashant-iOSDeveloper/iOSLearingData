//
//  ViewController.swift
//  Practics
//
//  Created by Prashant Sharma on 07/06/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    private var loginViewModel : LoginViewModel!
    
    var firstRow = 5

    var changeRow = Int()
    var changeRow1 = Int()

    override func viewDidLoad() {
        super.viewDidLoad()
        emailTF.delegate = self
        activityIndicator.isHidden = true
        passwordTF.delegate = self
        // Do any additional setup after loading the view.
     //   checkValueAndMove()
       
    }
    

  
//    func checkValueAndMove() {
//
//        for _ in 2...300 {
//            if firstRow == nil {
//                break
//            }
//            changeRow += 1
//            changeRow1 = changeRow
//        }
//
//
//    }

    
    func callToViewModelForUIUpdate(){
        
       let email = emailTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTF.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if email?.isEmpty == true || password?.isEmpty == true {
            self.activityIndicator.isHidden = true
            self.activityIndicator.hidesWhenStopped = true
            showAlert()
        }else {
            self.loginViewModel = LoginViewModel(email ?? "", password ?? "")
            self.loginViewModel.bindUserViewModelToController = {
                print(self.loginViewModel.user.access)
                UserDefaults.standard.set(true, forKey: "UserLoggedIn")
                DispatchQueue.main.async {
                    self.activityIndicator.isHidden = true
                    self.activityIndicator.hidesWhenStopped = true
                    self.naviateToDashboard()
                }
            }
        }
        
 
    }
    
    @IBAction func loginButtonClicked(_ sender: UIButton) {
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()
        callToViewModelForUIUpdate()
    }
    
    func naviateToDashboard() {
       let vc = mainStoryboard.instantiateViewController(withIdentifier: controllerIdentifier.dashboard)
       self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showAlert() {
        
        let alert = UIAlertController(title: Alert.Error, message: Alert.Msg, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: Alert.done, style: .cancel, handler: nil))
    
        self.present(alert, animated: true, completion: nil)
    }
    
}


extension ViewController : UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let currentText = textField.text ?? ""

           guard let stringRange = Range(range, in: currentText) else { return false }

           let updatedText = currentText.replacingCharacters(in: stringRange, with: string)

           return updatedText.count <= 50
    
    
    }
    
   
}
