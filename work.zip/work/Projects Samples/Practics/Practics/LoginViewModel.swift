//
//  LoginViewModel.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import Foundation

struct KEYS {
  static let email = "email"
    static let password = "password"

}

class LoginViewModel  {
    
    
    var email : String?
    var password : String?
    
    private(set) var user : LoginModel! {
        didSet {
            self.bindUserViewModelToController()
        }
    }
        var bindUserViewModelToController : (() -> ()) = {}
        
    init(_ email : String , _ password : String) {
       
        self.email = email
        self.password = password
        self.callFuncToGetUserData(email, password )
    }

    
    func callFuncToGetUserData(_ email : String , _ password : String) {
      
        let dict = [KEYS.email : email, KEYS.password : password] as? NSDictionary
        
        NetworkManager.shared.getResponse(apiUrl: ApiURL.login, body: dict, method: .POST, model: LoginModel.self) { [weak self]  results in
            
            switch results {
            case .failure(let error):
                print(error)
                self?.user.error = error
            case .success(let response):
                print(response)
                self?.saveData(response)
                self?.user = response
             }
            
            
        }
    }
    
    func saveData(_ loginModel : LoginModel) {
        
        let user = Login(context: DBManager.shared.context)
        user.email = loginModel.user?.email
        user.first_name = loginModel.user?.first_name
        user.last_name = loginModel.user?.last_name
        user.access = loginModel.access
        DBManager.shared.saveContext()
    }
    
    
}

extension Encodable {

    var dict : [String: Any]? {
        guard let data = try? JSONEncoder().encode(self) else { return nil }
        guard let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] else { return nil }
        return json
    }
}
