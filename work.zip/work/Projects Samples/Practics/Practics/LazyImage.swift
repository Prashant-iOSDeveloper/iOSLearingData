//
//  LazyImage.swift
//  Practics
//
//  Created by Prashant Sharma on 30/06/22.
//

import Foundation
import UIKit

class LazyImage : UIImage {
    
    
    
    
    
}
