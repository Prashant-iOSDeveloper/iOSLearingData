//
//  DetailsViewController.swift
//  Practics
//
//  Created by Prashant Sharma on 09/06/22.
//

import UIKit

class DetailsViewController: UIViewController , UITableViewDataSource {
    
    @IBOutlet weak var DetailtableView: UITableView!
    
     var details : Results?
 
    private var keysArr : Array<String>?
     private var valuesArr : Array<Any>?
    
     override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.title = "Emplyee Records"

        DetailtableView.dataSource = self
        keysArr = details?.dict?.keys.map{$0}
        valuesArr = details?.dict?.values.map {$0}
        
        // Do any additional setup after loading the view.
    }
    


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return keysArr?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomerDetails", for: indexPath)
        
        cell.textLabel?.text = keysArr?[indexPath.row].capitalizingFirstLetter()
        if let value = "\(valuesArr?[indexPath.row] ?? "")" as? String {
            cell.detailTextLabel?.text = value.capitalizingFirstLetter()
        }
        
    return cell
        
    }
    

}
