//
//  Employee+TableViewDelegates.swift
//  Practics
//
//  Created by Prashant Sharma on 09/06/22.
//

import Foundation
import UIKit

extension DashboardViewController : UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard  let details = employeeViewModel.user.results?[indexPath.row] else {return}
        let vc = mainStoryboard.instantiateViewController(withIdentifier: controllerIdentifier.details) as? DetailsViewController
        vc?.details = details
        self.navigationController?.pushViewController(vc!, animated: true)
        
    }
    
}
