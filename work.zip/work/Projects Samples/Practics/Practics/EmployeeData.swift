//
//  Employee.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import Foundation


class EmployeeData {
    
    
    private(set) var user : EmployeeModel! {
        didSet {
            self.bindUserViewModelToController()
        }
    }
        var bindUserViewModelToController : (() -> ()) = {}
    
    init() {
        self.callFuncToGetEmployee()
    }
    
    func callFuncToGetEmployee() {
      
        let token = "Bearer " + (fetchTokenFromCoreData() ?? "")
        NetworkManager.shared.getResponse(apiUrl: ApiURL.getEmployee, body: nil, token: token , method: .GET, model: EmployeeModel.self) { [weak self]  results in
            switch results {
            case .failure(let error):
                print(error)
                
               // if failed then assign from coreData
                
                
            case .success(let response):
                print(response)
                self?.saveData(response)
                self?.user = response
             }
        }
    }
    
    func saveData(_ loginModel : EmployeeModel) {
  
        for obj in loginModel.results ?? [] {
            let emp = EmployeeRecord(context: DBManager.shared.context)
            setValueFromCodeData(emp, obj: obj)
            DBManager.shared.saveContext()
            
    }
    }
    
    func setValueFromCodeData(_ emp : EmployeeRecord , obj : Results ) {
        
        emp.first_name = obj.first_name
        emp.last_name =  obj.last_name
        emp.email     =  obj.email
        emp.dob      =   obj.dob
        emp.hire_date =   obj.hire_date
        emp.address =  obj.address
        emp.city  =    obj.city
        emp.country  =  obj.country
        emp.zip_code   =    obj.zip_code
        emp.phone    =  obj.phone
        emp.salary =   obj.salary
        emp.designation  =  obj.designation
        emp.organization_name  =  obj.organization_name
        emp.status =  obj.status
        
    }
    
    func fetchTokenFromCoreData () -> String? {
        
        do {
            let request = Login.fetchRequest()
            let result = try DBManager.shared.context.fetch(request)
            return result.first?.access
        }
        catch let error {
          print(error)
        }
     return nil
        
    }
    
    func fetchEmpFromCoreData () -> [EmployeeRecord]? {
        do {
            let request = EmployeeRecord.fetchRequest()
            let result = try DBManager.shared.context.fetch(request)
            return result
        }
        catch let error {
          print(error)
        }
     return nil
        
    }

    
}
