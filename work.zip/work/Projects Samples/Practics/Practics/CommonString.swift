//
//  CommonString.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import Foundation
import UIKit


let mainStoryboard = UIStoryboard.init(name: "Main", bundle: Bundle.main)

struct ApiURL {
    
    static let login = URL(string: "https://api.equation.consolebit.com/api/v1/auth/login/")
    static let getEmployee = URL(string: "https://api.equation.consolebit.com/api/v1/testing/employee/")
    
    
}

struct Alert {
    
    static let Error = "ERROR"
    static let Msg = "invalid credentials"
    static let done = "Ok"
}

struct controllerIdentifier {
    
    static let dashboard = "DashboardViewController"
    static let details = "DetailsViewController"
    
}
