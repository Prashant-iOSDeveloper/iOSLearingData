//
//  LazyViewController.swift
//  Practics
//
//  Created by Prashant Sharma on 30/06/22.
//

import UIKit

class LazyViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
