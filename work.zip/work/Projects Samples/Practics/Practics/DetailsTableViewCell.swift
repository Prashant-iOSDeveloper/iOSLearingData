//
//  DetailsTableViewCell.swift
//  Practics
//
//  Created by Prashant Sharma on 19/06/22.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {

    var keys : String? {
        didSet {
            self.detailTextLabel?.text = keys
        }
    }
    var values : String? {
        didSet {
            self.detailTextLabel?.text = values
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
