//
//  NetworkManager.swift
//  Practics
//
//  Created by Prashant Sharma on 07/06/22.
//

import Foundation


class NetworkManager {
    
    static let shared = NetworkManager()
    
    private init(){}
    
    enum Method : String {
        case GET
        case POST
    }
    
    enum errorType : Error {
        
        case invalidURL
        case invaildResponse
        case unknown
        
    }
    
    func getResponse <T : Codable>( apiUrl : URL? , body : NSDictionary? = nil, token : String? = nil , method : Method , model : T.Type , completion : @escaping (Result<T,Error>) -> Void)  {
        
        guard let url = apiUrl else {
            completion(.failure(errorType.invalidURL))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.setValue(token, forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if body != nil {
        request.httpBody = try? JSONSerialization.data(withJSONObject: body ?? [:])
        }
     
        
        let task = URLSession.shared.dataTask(with: request) { data, _, error in
            
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                }else {
                    completion(.failure(errorType.invaildResponse))
                }
                return
            }
                do {
                    let result = try JSONDecoder().decode(model, from: data)
                    completion(.success(result))
                }
                catch let error{
                    completion(.failure(error))
                }                
        }
        task.resume()
                
    }
    
    
    
    
    
    
}

