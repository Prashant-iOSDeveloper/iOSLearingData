//
//  EmployeeTableViewCell.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import UIKit

class EmployeeTableViewCell: UITableViewCell {
    
    var employee : Results? {
        didSet {
            self.textLabel?.text = "\(employee?.first_name?.capitalizingFirstLetter() ?? "")" + " " + "\(employee?.last_name ?? "")"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
