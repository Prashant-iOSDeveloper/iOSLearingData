//
//  EmployeeModel.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import Foundation


struct EmployeeModel : Codable {
    let count : Int?
    let next : String?
    let previous : String?
    let results : [Results]?

    enum CodingKeys: String, CodingKey {

        case count = "count"
        case next = "next"
        case previous = "previous"
        case results = "results"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        count = try values.decodeIfPresent(Int.self, forKey: .count)
        next = try values.decodeIfPresent(String.self, forKey: .next)
        previous = try values.decodeIfPresent(String.self, forKey: .previous)
        results = try values.decodeIfPresent([Results].self, forKey: .results)
    }


}

struct Results : Codable {
    let id : Int?
    let first_name : String?
    let last_name : String?
    let email : String?
    let dob : String?
    let hire_date : String?
    let address : String?
    let city : String?
    let zip_code : String?
    let country : String?
    let phone : String?
    let photo : String?
    let salary : String?
    let designation : String?
    let organization_name : String?
    let status : String?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case first_name = "first_name"
        case last_name = "last_name"
        case email = "email"
        case dob = "dob"
        case hire_date = "hire_date"
        case address = "address"
        case city = "city"
        case zip_code = "zip_code"
        case country = "country"
        case phone = "phone"
        case photo = "photo"
        case salary = "salary"
        case designation = "designation"
        case organization_name = "organization_name"
        case status = "status"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        first_name = try values.decodeIfPresent(String.self, forKey: .first_name)
        last_name = try values.decodeIfPresent(String.self, forKey: .last_name)
        email = try values.decodeIfPresent(String.self, forKey: .email)
        dob = try values.decodeIfPresent(String.self, forKey: .dob)
        hire_date = try values.decodeIfPresent(String.self, forKey: .hire_date)
        address = try values.decodeIfPresent(String.self, forKey: .address)
        city = try values.decodeIfPresent(String.self, forKey: .city)
        zip_code = try values.decodeIfPresent(String.self, forKey: .zip_code)
        country = try values.decodeIfPresent(String.self, forKey: .country)
        phone = try values.decodeIfPresent(String.self, forKey: .phone)
        photo = try values.decodeIfPresent(String.self, forKey: .photo)
        salary = try values.decodeIfPresent(String.self, forKey: .salary)
        designation = try values.decodeIfPresent(String.self, forKey: .designation)
        organization_name = try values.decodeIfPresent(String.self, forKey: .organization_name)
        status = try values.decodeIfPresent(String.self, forKey: .status)
    }

}
