//
//  DashboardViewController.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//

import UIKit

class DashboardViewController: UIViewController {


    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var employeeTableView: UITableView!
     var employeeViewModel : EmployeeData!
    private var dataSource : EmployeeTableViewDataSource<EmployeeTableViewCell,Results>!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        employeeTableView.delegate = self
        self.navigationController?.isNavigationBarHidden = false
        self.navigationItem.setHidesBackButton(true, animated: false)
        self.activityIndicator.isHidden = true
        self.activityIndicator.hidesWhenStopped = true
        callToViewModelForUIUpdate()
        // Do any additional setup after loading the view.
    }
    
    func callToViewModelForUIUpdate(){
        
        self.employeeViewModel =  EmployeeData()
        self.employeeViewModel.bindUserViewModelToController = {
            self.updateDataSource()
            DispatchQueue.main.async {
                self.activityIndicator.isHidden = true
                self.activityIndicator.hidesWhenStopped = true
            }
          
        }
    }
    

    @IBAction func logoutBtnClicked(_ sender: UIBarButtonItem) {
        
        let domain = Bundle.main.bundleIdentifier!
        UserDefaults.standard.removePersistentDomain(forName: domain)
        UserDefaults.standard.synchronize()
        DBManager.shared.deleteAllData("Login")
        let sceneDelegate = UIApplication.shared.connectedScenes
               .first!.delegate as! SceneDelegate
        sceneDelegate.showLoginScreen()
    //    DBManager.shared.deleteAllData("Employee")
    }
    

    func updateDataSource(){
        self.dataSource = EmployeeTableViewDataSource(cellIdentifier: "EmpCell", items: self.employeeViewModel.user.results ?? [], configureCell: { (cell, evm) in
            cell.employee = evm
        })
        
        DispatchQueue.main.async {
            self.employeeTableView.dataSource = self.dataSource
            self.employeeTableView.reloadData()
        }
    }
    
}




extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).capitalized + dropFirst()
    }

    mutating func capitalizeFirstLetter() {
        self = self.capitalizingFirstLetter()
    }
}
