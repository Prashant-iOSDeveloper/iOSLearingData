//
//  EmployeeRecord+CoreDataProperties.swift
//  Practics
//
//  Created by Prashant Sharma on 09/06/22.
//
//

import Foundation
import CoreData


extension EmployeeRecord {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<EmployeeRecord> {
        return NSFetchRequest<EmployeeRecord>(entityName: "EmployeeRecord")
    }

    @NSManaged public var address: String?
    @NSManaged public var city: String?
    @NSManaged public var country: String?
    @NSManaged public var designation: String?
    @NSManaged public var dob: String?
    @NSManaged public var email: String?
    @NSManaged public var first_name: String?
    @NSManaged public var hire_date: String?
    @NSManaged public var id: Int64
    @NSManaged public var last_name: String?
    @NSManaged public var organization_name: String?
    @NSManaged public var phone: String?
    @NSManaged public var photo: String?
    @NSManaged public var salary: String?
    @NSManaged public var status: String?
    @NSManaged public var zip_code: String?

}

extension EmployeeRecord : Identifiable {

}
