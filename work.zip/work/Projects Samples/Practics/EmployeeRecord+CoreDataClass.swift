//
//  EmployeeRecord+CoreDataClass.swift
//  Practics
//
//  Created by Prashant Sharma on 09/06/22.
//
//

import Foundation
import CoreData

@objc(EmployeeRecord)
public class EmployeeRecord: NSManagedObject {

}
