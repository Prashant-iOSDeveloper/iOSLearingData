//
//  Login+CoreDataClass.swift
//  Practics
//
//  Created by Prashant Sharma on 08/06/22.
//
//

import Foundation
import CoreData

@objc(Login)
public class Login: NSManagedObject {

}
