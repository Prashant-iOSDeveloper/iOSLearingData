//
//  LoginTestUnitTests.swift
//  PracticsTests
//
//  Created by Prashant Sharma on 31/07/22.
//

import XCTest
@testable import Practics

class LoginTestUnitTests: XCTestCase {

    func test_LoginApi_withVaild_request_LoginResponse() {
        
        // Arrange
        let viewModel = LoginViewModel("test@example.com", "testing@example")
        let expectation = self.expectation(description: "withVaild_request_LoginResponse")
        
        // ACT
        viewModel.bindUserViewModelToController = {
            
            //ASSETS
            XCTAssertNotNil(viewModel.user.access)
            XCTAssertNil(viewModel.user.error)
            
            XCTAssertEqual("test@example.com", viewModel.email)
            XCTAssertEqual("test", viewModel.user.user?.first_name)
           // XCTAssertEqual("Doe", viewModel.user.user?.last_name)
            expectation.fulfill()
            

        }
       waitForExpectations(timeout: 5)
    
        
    }
    

}
