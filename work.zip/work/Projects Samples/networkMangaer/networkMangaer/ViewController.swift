//
//  ViewController.swift
//  networkMangaer
//
//  Created by Prashant Sharma on 04/07/22.
//

import UIKit


class ViewController: UIViewController {
    
    private var user = User()
    private var viewModel : ViewModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        callToVM()
        
      //  saveData()
        getData()
        
        switch viewModel {
            
        case .some(let value ) :
          print(value)
        case .none :
            print("no value ")
            
        }
      
    }
    
    func saveData() {
        do {
            try  KeyChainManager.save("Something".data(using: .utf8) ?? Data(),
                                      service: "Prashant",
                                      account: "facebook.com")
        }
        catch  {
            print(error)
        }
      
    }
    func getData() {
        guard let result =  KeyChainManager.get(service: "Prashant", account: "facebook.com") else {
            print("error")
            return
            }
        let password = String(decoding: result, as: UTF8.self)
        print(password)
    }
    
    

    func callToVM() {
        self.viewModel = ViewModel()
        
        viewModel?.dataToViewController = { [weak self] in
            print(self?.viewModel?.dataSource)
        }
    }
  
}

