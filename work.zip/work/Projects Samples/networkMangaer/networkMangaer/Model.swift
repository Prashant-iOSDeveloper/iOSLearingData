//
//  model.swift
//  networkMangaer
//
//  Created by Prashant Sharma on 10/07/22.
//

import Foundation



struct User : Codable {
    
    var fact  : String?
    var length : Int?
    
}
