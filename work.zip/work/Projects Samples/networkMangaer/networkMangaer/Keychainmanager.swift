//
//  Keychainmanager.swift
//  networkMangaer
//
//  Created by Prashant Sharma on 10/07/22.
//

import Foundation

class KeyChainManager {
    
    enum KeychainError : Error {
        case duplicateEntry
        case unknownError (OSStatus)
    }
    
    static func save(_ password : Data , service : String , account : String) throws {
        // service, account , class , data , password
        print("start saving")
        let query : [String : AnyObject] = [
            kSecClass as String :  kSecClassGenericPassword,
            kSecAttrService as String : service as AnyObject,
            kSecAttrAccount as String :  account  as AnyObject,
            kSecValueData  as String : password as AnyObject
        ]
        
        let status  = SecItemAdd(query as CFDictionary, nil)
        
        guard status != errSecDuplicateItem else {
            throw KeychainError.duplicateEntry
        }
        
        guard status == errSecSuccess else {
            throw KeychainError.unknownError(status)
        }
        
        print("Saved")
    }
    
    
    
    static func get(service : String , account : String) -> Data? {
        // service, account , class , data , password
        print("start saving")
        let query : [String : AnyObject] = [
            kSecClass as String :  kSecClassGenericPassword,
            kSecAttrService as String : service as AnyObject,
            kSecAttrAccount as String :  account  as AnyObject,
            kSecReturnData  as String : kCFBooleanTrue,
            kSecMatchLimit as String : kSecMatchLimitOne
        ]
        
       // let status  = SecItemAdd(query as CFDictionary, nil)
        var result : AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary , &result)
        
      
        print(status)
        
        
        
        
        
        return result as? Data
      
       
    }
    
}
