//
//  viewModel.swift
//  networkMangaer
//
//  Created by Prashant Sharma on 10/07/22.
//

import Foundation


class ViewModel {

    let url = "https://catfact.ninja/fact"
    
    private (set) var dataSource : User! {
        didSet {
            self.dataToViewController()
        }
    }
    
    var dataToViewController : () -> () = {}
    
    init () {
        callApi()
    }
    
    
    
    func callApi() {
  
    NetworkManager.shared.callAPi(url, methodType: .GET, model: User.self , body: nil, header: nil) { result in
    
        switch result {
        case .failure( let error) :
            print(error)
        case .success(let userData) :
            print("")
            self.dataSource = userData
            
        }

    }
     }
}
