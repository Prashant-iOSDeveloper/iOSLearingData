//
//  NetworkManager.swift
//  networkMangaer
//
//  Created by Prashant Sharma on 04/07/22.
//

import Foundation
import Combine

final class NetworkManager  {
    
    
    static let shared = NetworkManager()
    
    
    private init () {}
    
     
    enum ErrorType : Error {
        
        case dataNotAvaible
        case Unknown
        case urlInvalid
        
    }
    
    
    enum MethodType : String {
        case POST
        case GET
        
    }
    
    
    func callAPi <T : Codable>(_ urlString : String , methodType : MethodType , model : T.Type , body : NSDictionary? = nil , header : NSDictionary? = nil , completion : @escaping (Result<T,Error>) -> Void) {
        
        guard let url = URL(string: urlString) else {
            completion(.failure(ErrorType.urlInvalid))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = methodType.rawValue
        
//        if let body = body {
//            let jsonData =
//
//            //request.httpBody = body
//        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            
            guard let data = data else {
                
                if let error = error {
                    completion(.failure(error.localizedDescription as! Error))
                }else {
                    completion(.failure(ErrorType.Unknown))
                }
                return
            }
            
            do {
                let result = try JSONDecoder().decode(model, from: data)
                completion(.success(result))
            }
            catch {
                debugPrint(error.localizedDescription)
                completion(.failure(ErrorType.dataNotAvaible))
                
            }
          
        }
        task.resume()
        
    }
    
    
}
