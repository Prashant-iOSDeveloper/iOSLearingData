//
//  ViewController.swift
//  LearningCoreData
//
//  Created by Prashant Sharma on 01/02/22.
//

import UIKit

class ViewController: UIViewController  {

    @IBOutlet weak var tableView: UITableView!
    
    
    private let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    private var items : [Person]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        self.fetch()
        // Do any additional setup after loading the view.
    }

    @IBAction func addButtonTapped(_ sender: UIButton) {
        let alert  = UIAlertController(title: "Add Person", message: "What is their name?", preferredStyle: .alert)
        
        alert.addTextField()
        
        let add = UIAlertAction(title: "Add", style: .default) { action in
            let person = Person(context: self.context!)
            person.name = alert.textFields?[0].text?.trimmingCharacters(in: .whitespacesAndNewlines)
            
            do {
                try self.context?.save()
            }
            catch {
                
            }
           
            self.fetch()
        }
        alert.addAction(add)
        self.present(alert, animated: true, completion: nil)

    }
    
   
    
   private func fetch () {
     
       do {
           //        let pred = NSPredicate(format: "name CONTAINS 'P'")
           let request = Person.fetchRequest()
//           let pred = NSPredicate(format: "name CONTAINS 'P'")
//           request.predicate = pred
           
//           let sort = NSSortDescriptor(key: "name", ascending: false )
//           request.sortDescriptors = [sort]
           let result = try context?.fetch(request)
           DispatchQueue.main.async {
               self.items = result
               self.tableView.reloadData()
           }
       }
       catch  {
         
       }
    }
    
    
  
}


extension ViewController :  UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PersonCell", for: indexPath)
        let person = self.items?[indexPath.row]
        
        cell.textLabel?.text = person?.name
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        items?.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let person = self.items?[indexPath.row]
        
        let alert  = UIAlertController(title: "Edit Person", message: "Edit name:", preferredStyle: .alert)
        
        alert.addTextField()
        let textField = alert.textFields?[0]
        textField?.text = person?.name
        
        let saveButton = UIAlertAction(title: "Save", style: .default) { action in
            
            person?.name = textField?.text
            
            do {
                
                try self.context?.save()
            }
            catch {
                    
            }
            self.fetch()
            
        }
        alert.addAction(saveButton)
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        
        let action = UIContextualAction(style: .destructive, title: "Delete") { action, view, completion in
            
            let person = self.items![indexPath.row]
            
            self.context?.delete(person)
            
            do {
                
                try self.context?.save()
            }
            catch {
                    
            }
            self.fetch()
        }
        
        return UISwipeActionsConfiguration(actions: [action])
        
    }
    
}
