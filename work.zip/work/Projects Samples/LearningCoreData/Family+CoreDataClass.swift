//
//  Family+CoreDataClass.swift
//  LearningCoreData
//
//  Created by Prashant Sharma on 03/05/22.
//
//

import Foundation
import CoreData

@objc(Family)
public class Family: NSManagedObject {

}
