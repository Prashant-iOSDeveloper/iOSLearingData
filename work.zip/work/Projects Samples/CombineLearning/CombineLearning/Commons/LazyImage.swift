//
//  LazyImage.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 25/07/22.
//

import Foundation
import UIKit

class LazyImageView  : UIImageView {
    
    private let imageCache = NSCache<AnyObject, UIImage>()
    
    func loadImage (fromUrl imageUrl : URL)  {
        self.image = UIImage(named: "picture")
        
        if let cachedImage = self.imageCache.object(forKey: imageUrl as AnyObject)  {
            self.image = cachedImage
            return
        }
        
        
        DispatchQueue.global().async { [weak self] in
            
            if let imageData = try? Data(contentsOf: imageUrl) {
                if let image = UIImage(data: imageData) {
                    DispatchQueue.main.async {
                        self?.imageCache.setObject(image, forKey: imageUrl as AnyObject)
                        self?.image = image
                    }
                }
                    
            }
        }
        
    }
    
    
}
