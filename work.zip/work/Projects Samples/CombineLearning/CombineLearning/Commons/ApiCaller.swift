//
//  ApiCaller.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 05/07/22.
//

import Foundation
import Combine
 
class ApiCaller {
    
   static let shared = ApiCaller()
    
//    func fetchData (completion : ([String]) -> Void) -> [String] {
//
//        return ["Apple","",""]
//
//    }
    
    func fetchCompanices() -> Future<[String] , Error> {
        
        return Future { promix in
            DispatchQueue.main.asyncAfter(deadline: .now()+3) {
                promix(.success(["Apple","Microsoft","Goolgle","Facebook"]))
            }
         
        }
        
    }
}
