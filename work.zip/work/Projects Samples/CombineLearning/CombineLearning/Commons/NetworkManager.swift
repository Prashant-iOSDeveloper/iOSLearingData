//
//  NetworkManager.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 25/07/22.
//

import Foundation
import Combine


struct contentDataModel : Codable {
    
     var id , numberOfLessons : Int
     var name , link , imageUrl : String
}


enum Errortype : Error {
    
    case invaildUrl
    case unknown
    case dataNotAvailable
    case invaildHttpresponse
}
class NetworkManager {
    
    static let shared = NetworkManager()
    
   private init () {}
    private var cancellable = Set<AnyCancellable>()

    func callApi<T : Codable>(_ urlString : String , model : T.Type) async throws -> T {
        
        
        guard let url = URL(string: urlString) else {
            throw Errortype.invaildUrl
        }
        
        let request = URLRequest(url: url)
        do {
            let (data, serverUrlResponse) = try await URLSession.shared.data(for: request)
            
            guard let httpStatusCode = (serverUrlResponse as? HTTPURLResponse)?.statusCode, (200...299).contains(httpStatusCode) else {
                throw Errortype.invaildHttpresponse
            }
//
//            guard data.isEmpty else {
//                throw Errortype.dataNotAvailable
//            }
            do {
                let result = try  JSONDecoder().decode(model.self, from: data)
                return result
            }catch {
                throw Errortype.unknown
                
            }
 
        }catch {
            print( "Failed to reach endpoint \(error)")
            throw error
        }
    
    }
    
    
    
    func callApiCombine<T : Codable>(_ urlString : String , model : T.Type) -> Future<T,Error>
    {
        return Future<T,Error> { [weak self] promise in
            
            guard let self = self , let url = URL(string: urlString)  else {
                return promise(.failure(Errortype.invaildUrl))
            }
            
            URLSession.shared.dataTaskPublisher(for: url)
                .tryMap { (data , response) -> Data in
                    guard let httpResponseStatus = (response as? HTTPURLResponse)?.statusCode,  (200...299).contains(httpResponseStatus) else {
                        throw Errortype.invaildHttpresponse
                    }
                    return data
                }
                .decode(type: model.self, decoder: JSONDecoder())
                .receive(on: RunLoop.main)
                .sink { completion in
                    switch completion {
                    case .failure(let error):
                        
                        promise(.failure(error))
                        
                    case .finished:
                        print("task finished")
                    }
                } receiveValue: { results in
                    promise(.success(results))
                }
                .store(in: &self.cancellable)
            
        }
        
    }
    
}
