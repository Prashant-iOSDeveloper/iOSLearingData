//
//  SecondViewController.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 24/07/22.
//

import UIKit
import Combine

extension Notification.Name {
    static let update  = Notification.Name("updateText")
}

struct Post {
    var title : String
}
class SecondViewController: UIViewController {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var subscriberLbl: UILabel!
    @IBOutlet weak var termAndConditionSwitch: UISwitch!
    @IBOutlet weak var privacyPolicySwitch: UISwitch!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var submitBtn: UIButton!
    
    
    @Published private var termAndCondition = false
    @Published private var privacyPolicy = false
    @Published private var name = ""
    
    // COMBINE publisher
    private var vaildToSubmit : AnyPublisher<Bool , Never> {
        
        return Publishers.CombineLatest3($termAndCondition, $privacyPolicy, $name)
            .map { terms , privacy , name in
                return terms && privacy && !name.isEmpty
            }.eraseToAnyPublisher()
        
    }
    
    var submitSubscriber : AnyCancellable?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textField.delegate = self
        nameTextField.delegate = self
        //
        submitSubscriber = vaildToSubmit
            .receive(on: RunLoop.main)
            .assign(to: \.isEnabled, on: submitBtn)
        
            // create Publisher
        let publisher = NotificationCenter.Publisher(center: .default, name: .update, object: nil)
            .map { (notification) -> String? in // combine with operator
                return (notification.object as? Post)?.title ?? ""
            }

        // create Subscriber
        let subscriber = Subscribers.Assign(object: subscriberLbl, keyPath: \.text)
        
        publisher.receive(subscriber: subscriber)
        
    }
    @IBAction func submitButtonAction(_ sender: UIButton) {
      
    }
    @IBAction func privacySwutch(_ sender: Any) {
        privacyPolicy.toggle()
        
    }
    @IBAction func termsswitch(_ sender: Any) {
        termAndCondition.toggle()
    }
    

    @IBAction func PublisherBtnAction(_ sender: UIButton) {
        
        let title = textField.text ?? ""
        let post = Post(title: title)
        NotificationCenter.default.post(name: .update, object: post)
        textField.text = nil
    }
   

}

extension SecondViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
          textField.resignFirstResponder()
       return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        name = textField.text ?? ""
      //  textField.resignFirstResponder()
    }
    
}
