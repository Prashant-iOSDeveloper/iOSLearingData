//
//  ViewController.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 05/07/22.
//

import UIKit
import Combine

class tableViewCell : UITableViewCell {
    
    let button : UIButton = {
        let btn = UIButton()
        btn.backgroundColor = .systemPink
        btn.setTitle("Button", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        
    return btn
     }()
    
    let action = PassthroughSubject<String , Never>()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        button.addTarget(self, action: #selector(buttonTapped), for: .touchUpInside)
        contentView.addSubview(button)
    }
    
    required init?(coder: NSCoder) {
        
      fatalError()
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        button.frame = CGRect(x: 10, y: 2, width: contentView.frame.width - 20, height: contentView.frame.height - 6)
    }
    
    @objc private func buttonTapped() {
        action.send("Cool Button tapped")
    }
}



class ViewController: UIViewController, UITableViewDataSource {
  
    
    var obersever = [AnyCancellable]() //  for received data
    var model = [String]()
    
    private let tableView : UITableView = {
       let table = UITableView()
        table.register(tableViewCell.self, forCellReuseIdentifier: "CELL")
        return table
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(tableView)
        tableView.frame = view.bounds
        tableView.dataSource = self
       ApiCaller.shared.fetchCompanices()
            .receive(on: DispatchQueue.main) // for update on main thread
            .sink(receiveCompletion: { completion in
                switch completion {
                case .failure(let error):
                    print(error)
                case .finished :
                    print("Finished")
                }
            }, receiveValue: { [weak self]  value in
                self?.model = value
                self?.tableView.reloadData()
            }).store(in: &obersever)
        // Do any additional setup after loading the view.
    }


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as? tableViewCell  else {
            fatalError()
           
        }
        cell.action.sink { str in
            print(str)
        }.store(in: &obersever)
     //   cell.textLabel?.text = model[indexPath.row]
        return cell
    }
    
}

