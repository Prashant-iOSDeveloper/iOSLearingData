//
//  ProfileViewController.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 24/07/22.
//

import UIKit
import Combine

class ProfileViewController: UIViewController {
    
    @IBOutlet weak var userNameTF: UITextField!
    @IBOutlet weak var PasswordTF: UITextField!
    @IBOutlet weak var ConfirmPasswordTF: UITextField!
    @IBOutlet weak var createAccountBtn: UIButton!
    
    // publisher..
    @Published var name = ""
    @Published var password = ""
    @Published var confirmPassword = ""
    
    var vaildateUsername : AnyPublisher <String? , Never> {
        
        return $name
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .removeDuplicates()
            .flatMap { username in
                return Future { promise in
                    self.usernameAvailble(username) { available in
                        promise(.success(available ? username : nil))
                    }
                }
            }
            .eraseToAnyPublisher()
    }
    
    var vaildatePassword : AnyPublisher <String? , Never> {
        
        return Publishers.CombineLatest($password, $confirmPassword)
            .map { password , confirmPassword in
                guard password == confirmPassword , password.count > 0 else {return nil}
                return password
            }
            .map({
                ($0 ?? "") == "password1" ? nil : $0
            })
            .eraseToAnyPublisher()
    }
    
    
    var vaildateCredentials : AnyPublisher <(String, String)? , Never> {
        
        return Publishers.CombineLatest(vaildateUsername, vaildatePassword)
            .receive(on: RunLoop.main)
            .map { username , password in
                guard let userName = username , let pwd = password else { return nil}
                return (userName , pwd)
                
            }
            .eraseToAnyPublisher()
    }
    
    
    // subscribers
    var createAccountSubscribers : AnyCancellable?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userNameTF.delegate = self
        PasswordTF.delegate = self
        ConfirmPasswordTF.delegate = self

        createAccountSubscribers = vaildateCredentials
            .map { $0 != nil}
            .receive(on: RunLoop.main)
            .assign(to: \.isEnabled, on: createAccountBtn)
    }
    

    private func usernameAvailble(_ username : String , completion : (Bool) -> Void ) {
        completion(true)
    }
    
    @IBAction func createAccountBtnAction(_ sender: Any) {
        
        
    }
    

}

extension ProfileViewController : UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
          textField.resignFirstResponder()
       return true
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if textField == PasswordTF { password = textField.text ?? ""   }
        else if textField == ConfirmPasswordTF {  confirmPassword = textField.text ?? ""  }
        else if textField == userNameTF  { name = textField.text ?? "" }
     
        textField.resignFirstResponder()
    }
    
    
    
}
 
