//
//  ContentViewController.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 25/07/22.
//

import UIKit

class ContentViewController: UIViewController {
    
 
    @IBOutlet weak var contentTableView: UITableView!
    var contentData = [contentDataModel]()
    private var vm = ContentViewModel()
    private var dataSource : TableViewDataSource<ContentTableViewCell , contentDataModel>!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        Task.init {
//            do {
//                try await callNetworkCall()
//            }catch {
//                throw error
//            }
//
//        }
      //  updateDataSource()
        // Do any additional setup after loading the view.
        
        self.contentData = vm.contentData
        self.updateDataSource()
    }
    
    @MainActor
    private  func callNetworkCall() async throws {
        let urlStr = "https://api.letsbuildthatapp.com/jsondecodable/courses"
        
        do {
            self.contentData = try await NetworkManager.shared.callApi(urlStr, model: [contentDataModel].self)
                self.updateDataSource()
        
           
            print(contentData)
        }catch {
            throw error
        }
    }
    
    
    private func updateDataSource() {
        self.dataSource =  TableViewDataSource(item: contentData, identifier: "contentCell", congigureCell: { cell, item in
            cell.contentData = item
        })
        
        DispatchQueue.main.async {
            self.contentTableView.dataSource = self.dataSource
            self.contentTableView.reloadData()
        }
    }
    
    
}
