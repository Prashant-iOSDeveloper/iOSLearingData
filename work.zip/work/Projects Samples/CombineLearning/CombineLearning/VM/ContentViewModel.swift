//
//  ContentViewModel.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 26/07/22.
//

import Foundation
import Combine

class ContentViewModel : ObservableObject {
    
    
    private var cancellable = Set<AnyCancellable>()
    @Published var contentData = [contentDataModel]()
    
    func getContentData() {
        let urlStr = "https://api.letsbuildthatapp.com/jsondecodable/courses"
        NetworkManager.shared.callApiCombine(urlStr, model: [contentDataModel].self)
            .sink { completion in
                switch completion {
                case .failure(let err):
                    print("error on content api call \(err)")
                case .finished:
                    print("Content api call finished")
                }
            } receiveValue: { [weak self] contents in
                self?.contentData = contents
            }
            .store(in: &self.cancellable)
        
    }
    
}
