//
//  ContentTableViewCell.swift
//  CombineLearning
//
//  Created by Prashant Sharma on 25/07/22.
//

import UIKit

class ContentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var contentImageView: LazyImageView!
    @IBOutlet weak var contentLbl: UILabel!
    @IBOutlet weak var contentUrlLink: UILabel!
    
    var contentData : contentDataModel? {
        didSet {
            contentLbl.text = contentData?.name
            contentUrlLink.text = contentData?.link
          //  contentImageView.image =  UIImage(systemName: "photo.fill")
//            contentImageView.contentMode = .scaleAspectFill
//
//
//            let imageData = try? Data(contentsOf: URL(string: contentData!.imageUrl)!)
//
//
//            contentImageView.contentMode = .scaleAspectFit
            contentImageView.loadImage(fromUrl: URL(string: contentData?.imageUrl ?? "")!)
            contentImageView.contentMode = .scaleAspectFit
           // contentImageView.clipsToBounds = true
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
