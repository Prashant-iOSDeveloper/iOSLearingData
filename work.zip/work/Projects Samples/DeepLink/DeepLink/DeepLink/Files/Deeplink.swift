//
//  Deeplink.swift
//  DeepLink
//
//  Created by Prashant Sharma on 23/06/22.
//

import Foundation

enum DeepLink : String {
    case home
    case scan
}
    