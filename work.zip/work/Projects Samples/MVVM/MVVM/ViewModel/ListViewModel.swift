//
//  ListViewModel.swift
//  MVVM
//
//  Created by Prashant Sharma on 23/05/22.
//

import Foundation


class UserViewModel : NSObject {
    
    private var network : NetworkManager!
    private (set) var  userData : [UserProfile]! {
        didSet {
            self.moveDataFromUserToController()
        }
    }
    
    var moveDataFromUserToController : (() -> ()) = {}
    
    override init() {
        super.init()
        self.network = NetworkManager()
        callToViewControllerToUIUpdate()
    }
    
    
    func callToViewControllerToUIUpdate() {
        
        self.network.networkCall(url: urlString.listUrl, body: nil, method: .GET, model: [UserProfile].self) { result in
            
            switch result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let users):
                print(users)
                self.userData = users
            }
            
        }
    }
    
}
