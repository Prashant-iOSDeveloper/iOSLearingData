//
//  ViewController.swift
//  MVVM
//
//  Created by Prashant Sharma on 23/05/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var usertableView: UITableView!
    private var userViewModel : UserViewModel!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    
    func getData() {
        
        
    }
    
}

