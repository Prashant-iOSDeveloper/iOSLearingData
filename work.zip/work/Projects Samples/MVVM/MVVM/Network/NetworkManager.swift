//
//  NetworkManager.swift
//  MVVM
//
//  Created by Prashant Sharma on 23/05/22.
//

import Foundation

class NetworkManager : NSObject {
    
    
  //  static let shared = NetworkManager()
    
    override init (){}
    private let sourcesURL = URL(string: "http://dummy.restapiexample.com/api/v1/employees")!
    
    enum Method  : String {
        case GET
        case POST
        case put
    }
    
    enum errorType  : Error {
        case invaildUrl
        case badResponse
        case unknown
    }
    
    
    func networkCall <T : Codable>( url : URL? , body : NSDictionary? ,  method : Method , model : T.Type, completion : @escaping (Result< T , Error>) -> Void) {
        
        guard let url = url else  {
            completion(.failure(errorType.invaildUrl))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        
        let task = URLSession.shared.dataTask(with: request) { data, _, error in
            
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                }else {
                    completion(.failure(errorType.unknown))
                }
                return
            }
            
            do {
                let result = try JSONDecoder().decode(model.self, from: data)
                completion(.success(result))
            }
            catch {
                completion(.failure(errorType.badResponse))
            }
            
        }
        task.resume()
        
        
    }
    
    
}
