//
//  CommonString.swift
//  MVVM
//
//  Created by Prashant Sharma on 23/05/22.
//

import Foundation

struct urlString  {
    
   static let listUrl = URL(string: "https://gist.githubusercontent.com/sanjeevkumargautam-nykaa/a2 ab56f3a0973bd415a41b10906a0683/raw/15136211cf4e810abaa 19dc0ec77641cd518cc26/products.json")
}
