//
//  ViewController.swift
//  sampleProgram
//
//  Created by Prashant Sharma on 29/04/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userTableView: UITableView!
    var user = [User]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
      
        
       
      
    }
  
   

   private func fetch() {
    NetworkManager.shared.callApi(url: Constant.baseUrl, method: .GET, model: [User].self) { [weak self] result in
            switch result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let users):
                DispatchQueue.main.async {
                    self?.user = users
                    self?.userTableView.reloadData()
                }
                
            }
        }
        
    }
    

}

