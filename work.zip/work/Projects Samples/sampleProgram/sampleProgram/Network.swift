//
//  Network.swift
//  sampleProgram
//
//  Created by Prashant Sharma on 29/04/22.
//

import Foundation
import UIKit

class NetworkManager  {
    
    
    static let shared = NetworkManager()
    
    
   private init() { }
    
  private  enum CustomError : Error {
        
        case invaildUrl
        case unknown
        case invaildData
    }

    enum Method : String {
        case GET
        case POST
    }
    
    
    func callApi <T : Codable> (url : URL? , method : Method , model : T.Type , completion : @escaping (Result<T, Error>) -> Void) {
        
        guard let url = url else {
            completion(.failure(CustomError.invaildUrl))
         return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "\(method)"
        request.allHTTPHeaderFields = ["content-Type" : "application/json"]
        
        let task = URLSession.shared.dataTask(with: request) { data, _ , error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                }else {
                    completion(.failure(CustomError.invaildData))
                }
            return
            }
            
            do {
                let result = try JSONDecoder().decode(model.self, from: data)
                completion(.success(result))
            }
            catch {
                completion(.failure(CustomError.invaildData))
            }
            
        }
        
        task.resume()
    }
    
    
//    func callApi ( _ urlString : String , completion : @escaping (Result<[Product] , Error> ) -> Void) throws  {
//        guard let url = URL(string: urlString) else {
//            throw UserFetchError.invaild
//        }
//
//        var request = URLRequest(url: url)
//        request.httpMethod = "GET"
//        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
//        let task =  URLSession.shared.dataTask(with: request) { [weak self] data, _, error in
//            if let error = error {
//                completion(.failure(error))
//            }else if let data = data {
//                do {
//                    let decoder = JSONDecoder()
//
//
//                    let result =  try? decoder.decode([Product].self, from: data)
//
//
//                    completion(.success(result ?? [Product]()))
//                }
//                catch {
//                    completion(.failure(error))
//                }
//            }else {
//                completion(.failure(UserFetchError.unknown as Error))
//            }
//        }
//        task.resume()
//    }


    
    




}

//
//func sendRequest <T: Decodable> ( for: T.Type = T.self , url : String ,  completion: @escaping (Result<T>,Error) -> Void) -> [T] {
//
//
//
//     let url = URL(string: url)!
//    var request = URLRequest(url: url)
//    request.httpMethod = "GET"
//
//    return sendRequest(url, method: method, headers: nil, body : nil) { data, response, error  in
//            guard let data = data else {
//                return completion(.failure(error ?? NSError(domain: "SomeDomain", code: -1, userInfo: nil)))
//            }
//            do {
//                let decoder = JSONDecoder()
//                try completion(.success(decoder.decode(T.self, from: data)))
//            } catch let decodingError {
//                completion(.failure(decodingError))
//            }
//        }
//
////    let session = URLSession.shared
////    session.dataTask(with: request) { (data, response, error) in
////        if let response = response {
////            print(response)
////        }
////        if let data = data {
////            do {
////                let json = try JSONSerialization.jsonObject(with: data, options: [])
////                print(json)
////             let decoder = JSONDecoder()
////                if let result = try? decoder.decode(T.self, from: data) {
////
////
////
////                }else {
////                    print(error?.localizedDescription)
////                }
////
////            } catch {
////                print(error)
////            }
////        }
//

//}


//public func sendRequest<T: Decodable>(for: T.Type = T.self,
//                                      url: String,
//                                      method: RequestMethod,
//                                      headers: HTTPHeaders? = nil,
//                                      body: JSON? = nil,
//                                      completion: @escaping (Result<T>) -> Void) {
//
//    return sendRequest(url, method: method, headers: headers, body:body) { data, response, error in
//        guard let data = data else {
//            return completion(.failure(error ?? NSError(domain: "SomeDomain", code: -1, userInfo: nil)))
//        }
//        do {
//            let decoder = JSONDecoder()
//            try completion(.success(decoder.decode(T.self, from: data)))
//        } catch let decodingError {
//            completion(.failure(decodingError))
//        }
//    }
//}

