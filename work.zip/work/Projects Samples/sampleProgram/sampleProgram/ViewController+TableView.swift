//
//  ViewController+TableView.swift
//  sampleProgram
//
//  Created by Prashant Sharma on 29/04/22.
//

import Foundation
import UIKit

extension ViewController : UITableViewDataSource , UITableViewDelegate {
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        user.count
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "USERCELL", for: indexPath) as? UserTableViewCell else { return UITableViewCell() }
        
        let result = user[indexPath.row]
        
        
        //cell.priceLbl.text = result.price
        cell.productLbl.text = result.name
      //  cell.ratingLbl.text = result.rating
        
        return cell
        
    }
    
}
