//
//  Model.swift
//  sampleProgram
//
//  Created by Prashant Sharma on 29/04/22.
//

import Foundation

struct User : Codable {
    
     public var name : String?
      public var price : Double?
     public var rating : Double?
    
    
}

struct Constant {
    static let baseUrl = URL(string: "https://gist.githubusercontent.com/sanjeevkumargautam-nykaa/a2ab56f3a0973bd415a41b10906a0683/raw/15136211cf4e810abaa19dc0ec77641cd518cc26/products.json")
}

struct Product : Codable {
    
    public var products : [User]?
}

