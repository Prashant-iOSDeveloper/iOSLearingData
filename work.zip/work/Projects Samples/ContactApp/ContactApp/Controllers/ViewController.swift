//
//  ViewController.swift
//  ContactApp
//
//  Created by Prashant Sharma on 12/06/22.
//

import UIKit
import ContactsUI
import Contacts

class ViewController: UIViewController  {
    
    @IBOutlet weak var contactTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var models = [Person]()
    var filteredData = [Person]()
    
    private var dataSource : ContactTableViewDataSource<UITableViewCell,Person>!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.delegate = self
        setUpNavigation()
        // Do any additional setup after loading the view.
    }
    
    
    //MARK: setUp Navigation.
    func setUpNavigation() {
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(didTapAdd))
    }
    
    //MARK: adding Contact from Contact book
    @objc func didTapAdd() {
        let vc = CNContactPickerViewController()
        vc.delegate = self
        present(vc, animated: true, completion: nil)
    }
    
    
    //MARK: Update to tableView
    func updateDataSource(){
        self.dataSource = ContactTableViewDataSource(cellIdentifier: "ContactCell", items: filteredData, configureCell: { (cell, obj) in
            (cell as? ContactTableViewCell)?.contact = obj
        })
        DispatchQueue.main.async {
            self.contactTableView.dataSource = self.dataSource
            self.contactTableView.reloadData()
        }
    }
    
}

//MARK: Contact Deletgate
extension ViewController : CNContactPickerDelegate {
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
        print(contact)
        let name = contact.givenName + " " + contact.familyName
        let identifier = contact.identifier
        let phn = getPhoneNo(phnObj: contact.phoneNumbers) ?? ""
        let model = Person(name: name, id: identifier, mobile: phn, source: contact)
        if !self.models.contains(where: {($0.name == model.name)}){
            models.append(model)
            filteredData = models
            updateDataSource()
        }
    }
    
    func  getPhoneNo (phnObj : [CNLabeledValue<CNPhoneNumber>]) -> String? {
        var userMobile : String?
        
        for data in phnObj {
            userMobile = data.value.stringValue
        }
        return userMobile
    }
    
}

//MARK: sarchBar Deletgate
extension ViewController : UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        filteredData = []
        if searchText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            filteredData = models
        }else {
            for data in models {
                if (data.name.lowercased().contains(searchText.lowercased()) || data.mobile.contains(searchText.lowercased())) {
                    filteredData.append(data)
                }
            }
        }
        updateDataSource()
    }
}
