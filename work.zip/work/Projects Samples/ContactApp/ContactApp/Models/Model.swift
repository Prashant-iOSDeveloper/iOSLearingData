//
//  Model.swift
//  ContactApp
//
//  Created by Prashant Sharma on 12/06/22.
//

import Foundation
import Contacts

struct Person {
    
    let name  : String
    let id : String
    let mobile : String
    let source : CNContact 
    
}
