//
//  ContactTableViewCell.swift
//  ContactApp
//
//  Created by Prashant Sharma on 12/06/22.
//

import UIKit

class ContactTableViewCell: UITableViewCell {

    @IBOutlet weak var contactLbl: UILabel!
    @IBOutlet weak var nameLbl: UILabel!
    
    
    var contact : Person? {
        didSet {
            self.nameLbl.text = contact?.name
            self.contactLbl.text = contact?.mobile
        }
    }
        
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
