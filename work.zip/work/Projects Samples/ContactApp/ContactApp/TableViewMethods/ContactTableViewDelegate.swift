//
//  ContactTableViewDelegate.swift
//  ContactApp
//
//  Created by Prashant Sharma on 12/06/22.
//

import Foundation
import UIKit
import ContactsUI

extension ViewController : UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let contact = models[indexPath.row].source
        let vc = CNContactViewController(for: contact)
        present(UINavigationController(rootViewController: vc), animated: true, completion: nil)
        
        
    }
    
    
}
