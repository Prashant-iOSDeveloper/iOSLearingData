//
//  DemoSwiftUIApp.swift
//  DemoSwiftUI
//
//  Created by Prashant Sharma on 20/06/22.
//

import SwiftUI

@main
struct DemoSwiftUIApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
