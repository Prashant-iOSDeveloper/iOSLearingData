import UIKit

var greeting = "Hello, playground"

var str1 = "prashant"
var str2 = "tanhras"
var str3 = "rasanthp"

var arr = Array(str1).map{String($0)}
var arrOFStr1 = Array(str1.lowercased()).map{String($0)}
print(arr)


func addDict() {
    var dict : [String : Int] = [:]
for (key,value) in arr.enumerated() {
    if dict[value.description] != nil {
        dict[value.description]! += 1
        
    }else {
        dict[value.description] = 1
    }

    print(dict)
}
    

    
}
addDict()

func anagramStr(_ string1 : String , _ Str2 : String) -> Bool  {
    
    
    return string1.lowercased().sorted() == Str2.lowercased().sorted()
    
}

anagramStr(str1, str2)

