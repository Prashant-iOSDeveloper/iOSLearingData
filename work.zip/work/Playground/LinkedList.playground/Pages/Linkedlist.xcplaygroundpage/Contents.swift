//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)


class LNode  {
    
    var value : Int
    var nextNode : LNode?
    
    init (value : Int , nextNode :  LNode?) {
        self.value = value
        self.nextNode = nextNode
    }
}


class List {
    
    var head : LNode?
    
    
    var last : LNode? {
        
        guard var node = head else { return nil}
        
        while node.nextNode != nil {
            node = node.nextNode!
        }
        return node
    }
    
    func insert(value : Int) {
        
        if head == nil {
            head = LNode(value: value, nextNode: nil)
            return
        }
        
        var current = head
        while current?.nextNode != nil {
            current = current?.nextNode
        }
        
        current?.nextNode = LNode(value: value, nextNode: nil)
        
        
    }
    
    func deleteNode(_ value : Int) {
        
        if value == head?.value {
            
            head = head?.nextNode
            return
            
        }
        
        var prev : LNode?
        var current = head
        
        while current != nil && current?.value != value {
            prev = current
            current = current?.nextNode
        }
        
        prev?.nextNode = current?.nextNode
    }
    
    
}
