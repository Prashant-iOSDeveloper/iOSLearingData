

var greeting = "Hello, playground"


//// create a node
//
//public class LLNode<T> {
//
//    var value : T
//    weak var next : LLNode?
//   weak var previous : LLNode?
//
//    public init (value : T) {
//
//        self.value = value
//    }
//
//}
//
//
//public class linkedlist<T> {
//
//    public typealias Node = LLNode<T>
//
//        var head : Node?
//       var first : Node? {
//        return head
//    }
//
//    var last : Node? {
//        guard var node = head else {return nil}
//        while let next = node.next {
//            node = next
//        }
//        return node
//    }
//}
//
//let linked = linkedlist<Int>()
//

class Node <T> {
    
    var value : T
    
    var next : Node?
    
    init (value : T , next : Node?) {
        self.value = value
        self.next = next
    }
    
}

protocol Compare {
    
    static func ==(lhs : Self , rhs : Self)-> Self
    
}



class LinkedList<T>{
    
   public typealias node = Node<T>
    
    var head : node?
    
    var first : node? {
        return head
    }
    
  
    var lastNode : node? {
        guard var node = head  else {return nil}
       // print(head?.value)
        while node.next != nil {
            print(node.value as Any)
            node = (node.next)!
        }
        print(node.value as Any)
        return node
    }

    
    func insert(value : T) {
        if first == nil {
            head = Node(value: value, next: nil)
            return
        }
        
        var current = head
        while current?.next != nil {
            
            current = current?.next
        }
        
        current?.next = Node(value: value, next: nil)
    }
    

    func deleteNodeOnValue<T>(_ value : T) {
        
        if head?.value as? Int == value as? Int {
            head = head?.next
        }
        
        var prev : node?
        print("head \(head?.value)")
        var current = head
        
        while current != nil && current?.value as? Int != value as? Int {
            prev = current
            current = current?.next
        }
        
        prev?.next = current?.next
    }
    
    
    func displayList() {
        print("LinkedList is here")
       print(lastNode)
        
    }
    
    
    
}

//
//let linkeed = LinkedList<Int>()
//linkeed.insert(value: 1)
//linkeed.insert(value: 2)
//linkeed.insert(value: 3)
//linkeed.insert(value: 4)
//linkeed.deleteNodeOnValue(2)
//
//linkeed.displayList()
//

//    10
//  5   14
//1    11 20

 
class Node_ {
    
    var value : Int?
    var leftNode : Node_?
    var rightNode : Node_?
    
    
    init(leftNode : Node_? , rightNode : Node_? , value : Int) {
        self.rightNode = rightNode
        self.value = value
        self.leftNode = leftNode
    }
    
}

// Left Branch
let nodeOne = Node_(leftNode: nil, rightNode: nil, value: 1)
let nodeFive = Node_(leftNode: nodeOne, rightNode: nil, value: 5)

//Right Branch
let nodeEleven = Node_(leftNode: nil, rightNode: nil, value: 11)
let nodeTwenty = Node_(leftNode: nil, rightNode: nil, value: 20)
let nodeForthee = Node_(leftNode: nodeEleven, rightNode: nodeTwenty, value: 14)


let nodeTen = Node_(leftNode: nodeFive, rightNode: nodeForthee, value: 10)


func search(node : Node_? , value : Int) -> Bool{
    
    if node == nil {
        return false
    }
    if node?.value == value {
        return true
    }
    if value > node?.value ?? 0 {
        return search(node: node?.rightNode, value: value)
    }else {
        return search(node: node?.leftNode, value: value)
    }
   
    
    
   // return false
}

search(node: nodeTen, value: 20)

// STACK -
class Mynode {
    
    var value : Int
    var next : Mynode?
    
    init(_ value : Int , _ next : Mynode?) {
        self.value = value
        self.next = next
        
    }
    
    
}


class Stack {
    
    var top : Mynode?
    
    
    func push(_ value  : Int) {
        
        if top?.value == nil {
            top?.value = value
        }else {
            let old = top?.value
            top = 
        }
        
    }
    
    func pop() -> Int? {
        
        return nil
        
    }
    
}

let stack = Stack()

