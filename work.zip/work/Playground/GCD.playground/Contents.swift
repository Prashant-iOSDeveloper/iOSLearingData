import UIKit
import Foundation
import Darwin

var greeting = "Hello, playground"
var queue1: DispatchQueue?



func firstQueue() {
    let serialQueue = DispatchQueue(label: "com.app.myqueue")
    
    serialQueue.async {
        for i in 0..<10 {
            print(i)
        }
    }

    for i in 20..<30 {
        print(i)
    }
}
 //firstQueue()
func exampleQoS() {
    let firstQueue = DispatchQueue.global()
        let secondQueue = DispatchQueue(label: "com.app.secondQueue", qos: .utility)
     
        firstQueue.async {
         
            for item in 20..<30 {
                print(item)
            }
        }
    secondQueue.async {
       
        for item in 1..<10{
            print(item)
        }
    }
        
    }
//exampleQoS()

struct workItemSt {
    
    func workintemRun() {
        
    var work : DispatchWorkItem?
    
    work = DispatchWorkItem {
    // task
        for i in 0...20 {
            guard  let w = work , !w.isCancelled else {
                break
            }
            print(i)
            sleep(1)
        }
    }
    
        work?.notify(queue: .main, execute: {
            print("completed")
        })
        
    let queue = DispatchQueue.global(qos: .utility)
        queue.async(execute: work!)
        queue.asyncAfter(deadline: .now() + .seconds(3)) {
            work?.cancel()
            print("cancelled")
        }
       
    
    }

}
let workitem = workItemSt()
//workitem.workintemRun()

func exampleQueue() {
    let queue = DispatchQueue(label: "com.app.queue", qos: .utility , attributes: .concurrent)
        
        queue.async {
            for _ in 1..<5{
                print("**********")
            }
        }
        
        queue.async {
            for _ in 1..<5{
                print("AAAAAAAAAA")
            }
        }
        
        queue.async {
            for _ in 1..<5{
                print("0000000000")
            }
        }
 
    }
//exampleQueue()

func test() {
    
    let queue =  DispatchQueue(label: "com.app.queue")
    DispatchQueue.main.async {
        queue.async {
            sleep(5)
            print("first")
        }
    }
    DispatchQueue.main.async {
        queue.async {
            sleep(3)
            print("second")
        }
    }
    
}
//test()
//exampleQueu()
func exampleConcurrentQueue() {
    let queue = DispatchQueue(label: "com.app.concurrentQueue", qos: .userInitiated , attributes: .concurrent)
        
        queue.async {
            for _ in 1..<5{
                print("**********")
            }
        }
        
        queue.async {
            for _ in 1..<5{
                print("AAAAAAAAAA")
            }
        }
        
        queue.async {
            for _ in 1..<5{
                print("0000000000")
            }
        }
    print("asdasd")
 
    }
//exampleConcurrentQueue()

func queueInactive(){
     let queue = DispatchQueue(label: "com.app.inactive", qos: .utility, attributes: .concurrent)
          queue1 = queue
     queue.async {
         for i in 1..<5{
              print(i)
         }
     }
 }
func globalQueue(){
    let globalqueue = DispatchQueue.global(qos: .userInitiated)
        globalqueue.async {
            for items in 1..<5{
                 print(items)
            }
        }
    }
//globalQueue()

func workItem() {
       let work = DispatchWorkItem{
           for item in 0..<5{
               print(item)
           }
       }
       
  // When the work item is dispatch, we notifiy here the main queue
       work.notify(queue: DispatchQueue.main) {
           print("Work item is dispatched")
       }
       
       //Execution of workitem on the main thread.
       work.perform()

       let queue = DispatchQueue.global()

       //Execution of workitem on the background thread using first method.
       queue.async(execute: work)
       
       //Execution of workitem on the background thread using second method.
       queue.async {
           print("****")
           work.perform()
       }
}
//workItem()


func doLongTasksAndWait () {
    print("starting long running tasks")
    let group = DispatchGroup()          //create a group for a bunch of tasks we are about to do
    for i in 0...3 {                     //launch a bunch of tasks (eg a bunch of webservice calls that all need to be finished before proceeding to the next ViewController)
        group.enter()                    //let the group know that something is being added
        DispatchQueue.global().async {   //run tasks on a background thread
            sleep(arc4random() % 4)      //do some long task eg webservice or database lookup (here we are just sleeping for a random amount of time for demonstration purposes)
            print("long task \(i) done!")
            group.leave()                //let group know that the task is finished
        }
        group.enter()                    //let the group know that something is being added
        DispatchQueue.global().async {   //run tasks on a background thread
            sleep(arc4random() % 2)      //do some long task eg webservice or database lookup (here we are just sleeping for a random amount of time for demonstration purposes)
            print("long task \(i)")
            group.leave()                //let group know that the task is finished
        }
    }
    
    
    group.wait()                         //will block whatever thread we are on here until all the above tasks have finished (so maybe dont use this function on your main thread)
    print("all tasks done! 1")
    
    group.notify(queue: DispatchQueue.main) { //the queue: parameter is which queue this block will run on, if you need to do UI updates, use the main queue
        print("all tasks done!")              //this will execute when all tasks have left the group
    }
}
//doLongTasksAndWait()

class A {
    
  weak  var b : B?
    init(){
        print("init A")
    }
    deinit {
        print("deinit A")
    }
}
class B  {
    var a : A?
    init(){
        print("init B")
    
    }
    deinit {
        print("deinit B")
    }
}

if (1 == 1) {
 var objA : A? = A()
var objB : B? = B()
    objA?.b = objB
    objB?.a = objA
}






 func redeemVouchers(_ greetings: String, voucherValues: Int...) -> String {
     let voucherText = voucherValues.count > 0 ? " You have redeemed " + "\(voucherValues.reduce(0, +)) €" : ""
         return greetings + voucherText
     
     
     
     
 }

//redeemVouchers("Congratulation", voucherValues: 10,12)



enum getValue {
    case one(String)
    case two(Int,String)
    
}




class Dog  {
    
    init(value : String) {
        print("dog is init \(value)")
    }
    
    convenience init (withConv : String) {
        self.init(value: "new")
      
    }
    
}


var a = Dog(value: "")

var b = Dog(withConv: "okaok")

let makeGreeting : (String) -> String = { name in
    return name
}

//print(makeGreeting("BOB"))




func loop() {
    
    outerLoop: for i in 0...100 {
        print("run i \(i)")
        for j in 0...100 {
            print("run j \(j)")
            if j == 5 {
                break outerLoop
            }
        }
        break
    }
    
    print("out of function")
    
}
//loop()


func someMethod() {
    
    
    
    print("A")
    DispatchQueue.main.async {
        print("B")
        DispatchQueue.main.async {
            print("C")
            DispatchQueue.main.async {
                print("D")
            }
        }
}
}
//someMethod()
//A , B , C , D



struct Employee {
    
    
    func fetchEmployeeRecord () {
        
        print("Employee fetching stared")
        Thread.sleep(forTimeInterval: 3)
        print("Employee fetching complete")
        
    }
    
}

struct Board {
    
    
    func fetchBoardRecord () {
        
        print("Board fetching stared")
        Thread.sleep(forTimeInterval: 3)
        print("Board fetching complete")
        
    }
    
}

struct SyncManager {
    
    let employee = Employee()
    let board = Board()
    
    
    func gcdWork()  {
        
        let customQueue = DispatchQueue(label: "myQueue")
        
        customQueue.async {
            employee.fetchEmployeeRecord()
        }
        customQueue.async {
            board.fetchBoardRecord()
        }
        
    }
    
    
    func sync() {
        let employeeOperationQueue = BlockOperation()
       
        employeeOperationQueue.addExecutionBlock {
            employee.fetchEmployeeRecord()
        }

        let boardOperationQueue = BlockOperation()
        boardOperationQueue.addExecutionBlock {
            board.fetchBoardRecord()
        }
       boardOperationQueue.addDependency(employeeOperationQueue)
       
        
        let operationQueue = OperationQueue()
      
        operationQueue.addOperations([employeeOperationQueue,boardOperationQueue], waitUntilFinished: false)
     //   operationQueue.addOperation(boardOperationQueue)
           
    }
}

let objSync = SyncManager()
objSync.gcdWork()




//let queue = DispatchQueue(label: "label")
//queue.async {
//    queue.sync {
//        // outer block is waiting for this inner block to complete,
//        // inner block won't start before outer block finishes
//        // => deadlock
//    }
//    // this will never be reached
//}

