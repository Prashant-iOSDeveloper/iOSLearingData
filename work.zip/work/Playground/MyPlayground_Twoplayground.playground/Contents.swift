import UIKit

var greeting = "Hello, playground"


func addData(numbersArray: [Int], completion: @escaping (Int) -> Void) {

    let sum = numbersArray.reduce(0, +)

    completion(sum)
}


func callAddData() {

    let array = [1, 2, 3]

    addData(numbersArray: array) { sum in
        print("2: Sum of the array is -> \(sum)")
    }

    print("1: Sum of the array is -> \(array.reduce(0, +))")

}


callAddData()


var closureArray: [() -> ()] = []
var i = 0

for _ in 1...5 {
    closureArray.append {
        print("value of i ---> \(i)")
    }
    i += 1

}

closureArray[0]()
closureArray[4]()

protocol multiply {
    func result () -> Int
}

class Person : multiply {
   
    

    var value = 10
    var multiply = 2
    func result() -> Int {
        return value * multiply
    }
   

}

class User : multiply {
    var value = 10

    func result() -> Int {
        return value * value
    }
    

  

}


let p = Person()
print(p.result)
let u = User()
u.value = 3
print(u.result)
