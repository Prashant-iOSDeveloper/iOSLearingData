import UIKit
import PlaygroundSupport

PlaygroundPage.current.needsIndefiniteExecution = true

var greeting = "Hello, playground"

//
//class Airlines {
//
//
//    private var name : String = "United Airlines"
//
//   private var totalSeats = ["1A","2A","3A","4A"]
//
// //   let lock = NSLock()
//    let dispatchBarrier = DispatchQueue(label: "myQueue" , attributes: .concurrent)
//    func getAvailableSeats() -> [String] {
//        dispatchBarrier.sync(flags: .barrier) {
//        return totalSeats
//    }
//    }
//
//    func bookSeat() -> String? {
//        dispatchBarrier.sync(flags: .barrier) {
//            let bookSeat = totalSeats.last
//            totalSeats.removeLast()
//
//        return bookSeat
//    }
//    }
//
//}

class User {
    
    
    func deadlock() {
        
        let secQue = DispatchQueue(label: "queue")
        DispatchQueue.main.sync {
            print("myname")
            secQue.sync {
                print("yourName")
            }
        }
    }
    
    
    var arr = [1,2,3,4,5,6] // Shared resourse
 

     
     // A concurrent queue is created to run operations in parallel
     let queue = DispatchQueue(label: "test.queue", attributes: .concurrent)
   // queue.async(flags : .barrier) {
     let lock = NSLock()
    
    
    // 1 Create Semaphore object
        // Value here represents the number of concurrent threads can have access to particular section of code
        let semaphore = DispatchSemaphore(value: 1)
    
    
    func executeTask() {
     //   lock.lock()
     // First block of code added to queue for execution\
        semaphore.wait()
        queue.async {
            self.removeLast()
     }
        semaphore.signal()
   //     lock.unlock()
     // Second block of code added to queue for execution
     queue.async {
         self.removeAll()
     }
 
    }
 func removeAll() {
     print("Remove all entry")
     arr.removeAll()
     print("Remove all end")
     print(arr)
 }
 
 func removeLast() {
     print("Remove last entry")
     arr.removeLast()
     print("Remove last end")
     print(arr)
 }
}
    


let user = User()
user.executeTask()

class Customers {

    let airlines =  Airlines()

    let queue : DispatchQueue = DispatchQueue(label: "queue1")
    let queue1 = DispatchQueue(label: "queue2")

    func getData() {
       
        queue.async {
            Task {
           let seat = await self.airlines.bookSeat()
            print(seat)
        }
        }
        queue1.async {
            Task {
           let seats = await self.airlines.getAvailableSeats()
            print(seats)
        }
        }

    }
    @MainActor
    func updateUI() {
        print("update")
    }

}

let c = Customers()
c.getData()

actor Airlines {
    
    
    private var name : String = "United Airlines"

   private var totalSeats = ["1A","2A","3A","4A"]
    
 //   let lock = NSLock()
//    let dispatchBarrier = DispatchQueue(label: "myQueue" , attributes: .concurrent)
    func getAvailableSeats() -> [String] {
    //    dispatchBarrier.sync(flags: .barrier) {
        return totalSeats
    }
    ///   }
    
    func bookSeat() -> String? {
     //   dispatchBarrier.sync(flags: .barrier) {
            let bookSeat = totalSeats.last
            totalSeats.removeLast()
        
        return bookSeat
  //  }
    }
    
    
    
}

class Semaphor {
    
    let queue1 = DispatchQueue.global(qos: .userInteractive)
    let queue2 = DispatchQueue.global(qos: .utility)
    let queue3 = DispatchQueue.global(qos: .background)
    let semephor = DispatchSemaphore(value: 1)
    
    func printValue(_ emoji : String , queue : DispatchQueue) {
        queue.async {
            debugPrint("\(emoji) is waiting")
            self.semephor.wait()
        for i in 0...10 {
            print("\(emoji) , \(i)")
        }
            self.semephor.signal()
            debugPrint("\(emoji) is released")
        }
    }
   
}

let classObj = Semaphor()

classObj.printValue("🚐", queue: classObj.queue1)
classObj.printValue("🚓", queue: classObj.queue2)
classObj.printValue("✈️", queue: classObj.queue3)
