import UIKit

var greeting = "Hello, playground"


// enum with raw and associate both values.
enum Airport  {
    case munich
    case sanFrancisco
    case singapore
    case london(airportName: String)
    
    var cityIdentifier: String {
        switch self {
        case .munich:
            return "MUC"
        case .sanFrancisco:
            return "SFO"
        case .singapore:
            return "SIN"
        case .london:
            return "LON"
        }
    }
}

// enum associate  values.
enum Airport1 {
case munich
case sanFrancisco
case singapore
case london(airportName: String)
}

let v : Airport = .london(airportName: "new")
v.cityIdentifier



var arr =   [0,1,1,2,0,1,2,2,2,1,0,1,2,1,0]


func filterGreaterThenValue (value : Int , numbers : [Int]) -> [Int] {
    
    var filteredNumbers = [Int]()
    
    for num in numbers {
        if num > value {
            filteredNumbers.append(num)
        }
    }
    return filteredNumbers
    
}

let filteredList = filterGreaterThenValue(value: 4, numbers: [3,4,5,6,7])


func filterGreaterClosure (closure : (Int) -> Bool , numbers : [Int]) -> [Int]
{
    
    var filterdNum = [Int]()
    for num in numbers {
        if closure(num) {
            filterdNum.append(num)
        }
    }
    return filterdNum
    
}

let filter = filterGreaterClosure(closure: { num in
    num > 5
}, numbers: [3,5,6,7,8,9])
print(filter)



extension Array where Element == Int  {
    
    
    func myFilter (closure : (Element) -> Bool) -> [Element] {
        
        var filteredNum = [Element]()
        
        self.forEach { num in
            if closure(num) {
          filteredNum.append(num)
        }
        }
        print(filteredNum)
        return filteredNum
    }
    
}


let filterd  = arr.myFilter { num in
    num > 0
}

func sortZeroOneTwo(_ arr : inout [Int] ) {
    
    var zero = 0
    var one = 0
    var two = 0
    var i = 0
    var j = 0
    
    while i < arr.count - 1 {
        
        switch arr[i] {
            
        case 0 :
            zero += 1
        case 1 :
            one += 1
        case 2 :
            two += 1
            
        default: break
            
        }
        i += 1
    }
    print(zero,one,two)
  
    while j < arr.count - 1 {
        if zero > 0 {
            arr[j] = 0
            zero -= 1
        }
        if one > 0 {
            arr[j] = 1
            one -= 1
        }
        if two > 0 {
            arr[j] = 2
            two -= 1
        }
        j += 1
    }
}


print(sortZeroOneTwo(&arr))
print(arr)


// find smallest and second smallest

func smallest(_ arr : inout [Int]) -> (Int,Int) {
    
    var first = Int.max
    var second = Int.max
    
    for i in 0..<arr.count {
        
        if first < arr[i] {

            first = arr[i]
        }else if second > arr[i] {
            second = arr[i]
        }
    }
    return (first,second)
    
    
}

var arr1 = [-10,0,1,2,55,6,77,1,22]
smallest(&arr1)


func sayGoodMoring(_ str : String) {
    
    print(str)
}

func greetUser (_  meet : (String) -> Void)  {

    meet("name")
    
}

greetUser(sayGoodMoring(_:))


func higherOrderFunc (_ str : String) -> () -> String {
    
    func printValue() -> String {

        return ("hey , \(str)")
    }
    
    return printValue
}


let higherOrderF = higherOrderFunc("mhyanme")
higherOrderF()


@propertyWrapper
struct EmailVaildation {
   private var value : String
    var wrappedValue : String {
        set {
            value = newValue
        }
        get {
             isValidEmail(value) ? value : String()
        }
    }
    
    init (email : String) {
        
        self.value = email
    }
    
    func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
    
}

struct User {
    
    var name : String
    @EmailVaildation var emailTF : String
    
    
    func validate() -> Bool {
        
        if (name.isEmpty || emailTF.isEmpty) {
            print("invalid data")
            return false
        }
        return true
    }
    
}

let u = User(name: "prashant", emailTF: EmailVaildation(email: "ps@g.in"))
u.validate()


var str = "Aabbcbbacaba"

func getOutput(_ str : String) -> [String?] {
    let chars = Array(str).map({String($0)})
    var tempArr = [String]()
    for char in chars {
        tempArr.append(char)
    }
       print(tempArr)
    
    var  counter = 0
    for i in 0..<tempArr.count - 2 {
            
             let new = tempArr[i] + tempArr[i+1] + tempArr[i+2]
            print("value  \(new)")

        isPallindrom(new)
    }
    
    return [nil]

}
func isPallindrom(_ str : String) -> Bool { // "aabaa"
    
    
    var currentIndex = 0
    var arr = Array(str)
    while currentIndex < arr.count / 2 {
        print(arr[currentIndex])
        print(arr[arr.count - currentIndex - 1])
        if arr[currentIndex] != arr[arr.count - currentIndex - 1] {
            return false
        }
        currentIndex += 1
    }
    print("varified" + str)
    return true
    
}

getOutput(str)


class MyClass {
    
    @objc func name () {
        
        print( "value ")
    }
    
    
}



extension MyClass {
    
    func changeName () {
        print("changesd")
    }
    
    
}

class MySecond : MyClass {
    
    func hey() {
        
    }
    
    
}
extension MySecond  {
    
     override func name() {
        
    }
    
    
}

enum Profile {
    
    case notAvailable
    case available
    case online
    case offline
    
    
    func checkUser (_ user : Self) -> Bool{
        return true
    }
    
    
    var name : String {
        set {
            self.name = ""
        }
        get {
            return self.name
        }
        
    }
}



struct Player {
    
    var name : String
    var team : String
    var position : String
    
   lazy var introduction  = {
       
       return "now entering the game \(name), \(position) , for the \(team)"
    }()
    
}

var s = Player(name: "Player", team: "Bulls", position: "guard")
s.introduction
// lazy access and stored in object
// stored property // not thread safe
//123

func reverseNum(_ n : inout Int) {
    
    var reverse: Int = 0

    while (n != 0) {

    reverse = reverse * 10
    reverse = reverse + n % 10

    n = n / 10

    }

    print(reverse)
}
var nu = 112233
reverseNum(&nu)



var arr33 = [3,1,5,4,0]
var arr133 = [3,1,0,4,4]



func findtheMiddleIndex( _ arr : inout [Int]) -> Int {
    
    
   var leftSum = 0
    var rightSum = 0
    
    for i in 0..<arr.count {
        rightSum += arr[i]
        }
        
       
    for j in 0..<arr.count {
        rightSum = rightSum - arr[j]
        if leftSum == rightSum {
          return j
        }
        leftSum += arr[j]
    }
 
    return 0
    
}
findtheMiddleIndex(&arr133)
