import UIKit
import Darwin
import Foundation

var greeting = "Hello, playground"


//MARK - Single reponsibility

struct EmployeeModel : Codable {
    
    let id : String?
    let name : String?
    let address : String?
    
}

class httpHandler {
    
    func callApi () -> Data {
        return Data()
    }
}


class Parser {
    
    func parseApiResponse  (_ data : Data) -> Array<EmployeeModel> {
        
        return Array<EmployeeModel>()
    }
}

class DataBaseManager {
    
    func saveData (_ data : Array<EmployeeModel>) {
    
    }
}

class Employee {
   
    let perser : Parser
    let dbmanger : DataBaseManager
    let httphandler : httpHandler
    
    init (_ perser : Parser , dbmanger : DataBaseManager , httphandler :  httpHandler) {
        self.dbmanger = dbmanger
        self.perser = perser
        self.httphandler = httphandler
    }
    
      func getEmployeeData () -> Void {
        
          let empResponse = httphandler.callApi()
          let emplyeeData = perser.parseApiResponse(empResponse)
          dbmanger.saveData(emplyeeData)
        
    }
//
//    private func callEmployeeApi() -> Data {
//        // call api
//        return Data()
//    }
//
//    private func parseApiResponse (_ data : Data) -> Array<EmployeeModel> {
//
//        return Array<EmployeeModel>()
//    }
//    private func saveData (_ data : Array<EmployeeModel>) {
//
//    }
//
}

//MARK : Open close  :

protocol Shape {
    func area() -> Double
}

class Rectangle : Shape {
  
    let width : Double
    let height : Double
    
    init(_ width : Double , _ height : Double){
        
        self.width = width
        self.height = height
    }
    func area() -> Double {
        return width * height
    }
    
  
    
}

class Circle  : Shape {
    
    
    let radius : Double
    
    
    init(_ radius : Double ){
        
        self.radius = radius
    }
    
    func area() -> Double {
        return Double.pi * radius * radius
    }
   
    
}
class Triangle  : Shape {
    
    
    let base : Double
    let height : Double
    
    
    init(_ base : Double , _ height : Double ){
        
        self.base = base
        self.height = height
    }
    
    func area() -> Double {
        return 1/2 * base * height
    }
   
    
}

class AreaCalculator  {
    
    func area(_ shape : Shape) -> Double {
        return shape.area()
    }
    
    // change func here
    
}

let obj = AreaCalculator()
obj.area(Rectangle(2, 3))
obj.area(Circle(10))
obj.area(Triangle(2, 2))


//MARK: Liskov Substitution Principle



class Rectangle1  {
  
    
    
    var width : Double = 0
    var height : Double = 0
    
    var area : Double {
        width * height
    }
    
   
    
}

class Square : Rectangle1 {
    
    override var width : Double {
        didSet {
            height = width
        }
    }
    
    
}


let rect = Rectangle1()
rect.width = 2
rect.height = 4
print(rect.area)
let square = Square()
square.width = 3
print(square.area)




class Bird {
    
    func makeNoise() {
        print("crip crip")
    }
    
}

class Eagle : Bird {
    
    
    override func makeNoise() {
        print("ohhhhahhhhhhh")
    }
}

class Crow : Bird {
    
    
    override func makeNoise() {
       // fatalError("I forgot what my sound is")
    }
    
}

//let c = Crow()
//c.makeNoise()
//let

//MARK: - Interface segregation principle
protocol User {
    
    func save()
    func delete()
    func update()
    func modify()
    
}

//MARK: - dependancy inversion

struct Order {
    let amount : Double
    let tax : Double
    
}

protocol orderDataBase {
    
    func saveData(_ order : Order)
    
}

class Hanlder {
    
    
    private let orderDataBaseOperation : orderDataBase
    
    init (_ orderDataBaseOperation : orderDataBase) {
        self.orderDataBaseOperation = orderDataBaseOperation
    }
    
    func saveData(order : Order) {
        print("save")
        orderDataBaseOperation.saveData(order)
        
    }
    
}


class OrderDataBaseOperation : orderDataBase{
    func saveData(_ order: Order) {
        print("save")
    }
    
  
    
}

let orderObj = OrderDataBaseOperation()

let handler = Hanlder(orderObj)
handler.saveData(order: Order(amount: 10.01, tax: 100))


// Palindrom from arr
let str = "Aabbcbbacab"
let v = ["Eye", "Pop", "Noon", "Level", "Radar", "Kaya", "Rotator", "Redivider", "Detartrated", "Tattarrattat", "Aibohphobia", "Eve", "Bob", "Otto", "Anna", "Hannah", "Evil olive", "Mirror rim", "Stack cats", "Doom mood", "Rise to vote sir", "Step on no pets", "Never odd or even", "A nut for a jar of tuna", "No lemon, no melon", "Some men interpret nine memos", "Gateman sees name, garageman sees nametag"]

func getStringFromWords(_ obj : [String]) {
    
    //let arr = Array(obj).map({String($0)})
    
    
    for i in 0..<obj.count {

       // let stringofThree = arr[i] + arr[i+1] + arr[i+2]
        
      print(obj[i])
        print(isPalindromNo(from: obj[i].lowercased()))
    }

  
}


func isPalindromNo(from strObj : String) -> Bool {
   
     let arr = Array(strObj)
    
    for i in 0..<arr.count / 2 {
       
        if arr[i] != arr[arr.count - i - 1] {
            return false
        }
       
    }
    return true
}

//getStringFromWords(v)


public private(set) var school : String?

school = "name"



protocol Work {
    func printData()
    
}

class Shop {
    
    var workers : Work
    init (_ workers : Work ) {
        self.workers = workers
    }
    
    func anything() {
        workers.printData()
    }
}


class Workers : Work {
    
    func printData() {
        print("hey")
    }
    
}

var w = Workers()




enum PaymentMoode : String {
    
    case cash = "cash"
    case creditCard =  "CreditCard"
    case goolePay = "GooglePayPayment"
    
}

protocol PaymentServiceHandler {
    
    func paymentDone()
        
}


class PaymentService  {
    
    func paymentDone(paymentMode : PaymentServiceHandler) {
        paymentMode.paymentDone()
    }
    
    
//    func makePayment(payMode : PaymentMoode) {
//
//        switch payMode {
//        case .creditCard :
//            let creditCardPayment = CreditCardPayment()
//            creditCardPayment.paymentDone()
//        case .cash:
//            let cashPayment = CashPayment()
//            cashPayment.paymentDone()
//
//        case .goolePay:
//            let googlePayPayment = GooglePayPayment()
//            googlePayPayment.paymentDone()
//        }
//
//    }
    
}


class CashPayment  : PaymentServiceHandler {
    
   
    func paymentDone() {
   // some logic
        print("payment mode is : Cash")
    }
    
}

class CreditCardPayment : PaymentServiceHandler {
  
    func paymentDone() {
        // some logic
        print("payment mode is : CreditCard")
    }
    
}

class GooglePayPayment  : PaymentServiceHandler {
  
    func paymentDone() {
        // some logic
        print("payment mode is : GooglePayPayment")
    }
    
}

class PhonePay  : PaymentServiceHandler {
  
    func paymentDone() {
        // some logic
        print("payment mode is : PhonePay")
    }
    
}

let payment = PaymentService()
payment.paymentDone(paymentMode: PhonePay())
