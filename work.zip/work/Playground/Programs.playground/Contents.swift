import UIKit
import CoreFoundation
import Darwin
import Foundation

var greeting = "Hello, playground"

struct User {
    
    let name : String?
    let email : String?
}

//Prime No.
// ******************************************************************************************************
//MARK: - Prime No
func primeNum (arr : [Int] ) -> [Int] {
    
    var temp = [Int]()
   
    let queue = DispatchQueue(label: "New queue", qos: .userInteractive, attributes: .concurrent)
    
    queue.sync {
        for num in arr {
            if num > 2 {
                var isPrime = true
                for i in 2..<num  {
                    while num % i == 0 {
                        isPrime = false
                    }
                }
                if isPrime != false {
                    temp.append(num)
                }
            }else {
                temp.append(num)
            }
        }
    }

  //  print(temp)
    //print(stride(from: 3, through: 100, by: 3).enumerated())
    return temp
}

//print(primeNum(arr: [2, 5, 10, 8, 1, 0 , 15, 17, 21, 23 , 13]))

func primeCheck() {
    var primes = [2]

    for num in stride(from: 3, through: 100, by: 2 ){
        for p in primes {
            if p * p > num {
                primes.append(num)
                break
            }
            if num % p == 0 {
                break
            }
        }
    }

    print(primes)
}
// ******************************************************************************************************

//MARK: - Missing No
func checkMissignNumberFromArray(arr : [Int]) {
    
    var index1 = -1
    var sum = 0
    

    for (index, item) in arr.enumerated() {
        sum += item

    }
    let total = (( arr.count + 1 ) * (arr.count + 2))/2
    print("sum " + "\(total - sum)")
    print("index " + "\(index1)")
    
}

//checkMissignNumberFromArray(arr: [1,2,3,4,5,6,7,8,10])
    

//MARK: - Sort Array
func sort<T : Comparable>(_ array: inout [T]) {
  
    var i = 1
    
    while i < array.count {
        let x = array[i]
        var j = i - 1
        
        while j >= 0 && array[j] > x {
            array[j+1] = array[j]
            j -= 1
        }
        
        array[j+1] = x
        i += 1
    }
}

// ******************************************************************************************************



//MARK: - Duplicate from Array


extension Array where Element : Comparable { // / == Int
    
    func removeDuplicates () -> [Element] {
        
        guard !self.isEmpty else {return []}
        var temp = [Element]()
        self.forEach { item in
            if !temp.contains(item) {
                temp.append(item)
            }
        }
        
        return temp
    }
    
}

func findDuplicateFromArr(_ arr : [Int]) -> [Int] {
    
    guard !arr.isEmpty else {return []}
    var temp = [Int]()
    var duplicate = [Int]()
    for i in 0..<arr.count {
        if !temp.contains(arr[i]) {
            temp.append(arr[i])
        }else {
            duplicate.append(arr[i])
        }
    }
    return temp
}




//var duplicateArr = [1, 1, 2, 3, 4, 5, 5 , 5 ,6 ,8 , 9]
//duplicateArr.removeDuplicates()
//var strArr = ["a","c","r","r","a","b","s","b"]
//strArr.removeDuplicates()
//let val = findDuplicateFromArr(duplicateArr)

// ******************************************************************************************************

//MARK: Find capital from String

let yourName  = "Prashant SharmA"

func findCapital(fromString input : String) -> String? {
    
    guard !input.isEmpty else {return nil }
    let result = input.filter({("A"..."Z").contains($0)})
    
    
    return result
}

//findCapital(fromString: yourName)

// ******************************************************************************************************

//MARK: - Convert array of any to array of Int
let arrofAny : [Any] =  [true , 1 , "name" , 2 , false , "test"]
let result = arrofAny.compactMap { obj in
    return obj as? Int
}
//print(result)

// ******************************************************************************************************

//MARK: - heightest No.
func highestNum (arr : [Int]) -> Int {
    
    var hightest = Int()
    var secongHightest = Int()
    
    for i in 0..<arr.count  {
        
        if arr[i] > hightest {
            secongHightest = hightest
            hightest = arr[i]
        }
      
    }
    print(hightest)
    print(secongHightest)
    return secongHightest
}

//highestNum(arr: [1, 1, 2, 3, 4, 5, 5 , 5 ,6 ,8 , 9,10,20])

func findheightest(_ arr : [Int]) -> (Int,Int,Int,Int) {
    
    var heigtest = 0
    var sH = 0
    var lowest = Int.max
    var secondlo = Int.max
    
    for i in 0..<arr.count {
        
        if arr[i] > heigtest {
            sH = heigtest
            heigtest = arr[i]
        }else if arr[i] < lowest {
            lowest = arr[i]
        } else if arr[i] < secondlo{
            secondlo = arr[i]
        }
    }
        
    return (heigtest,sH , secondlo , lowest)
}

let arr = [-21, 3, 34, 45, 67, 88, 2 , -6]

//findheightest(arr)

// ******************************************************************************************************

//MARK: - Reverse String.
func reverseString(_ Str : String) -> String {
    
    var temp = ""
    for char in Str {
        temp = "\(char)" + temp
    }
    return temp
}

//print(reverseString("Prashant Sharma"))

// ******************************************************************************************************

func moveZeroes(_ nums: inout [Int]) {
    for i in 0..<nums.count {
        if nums[i] == 0 {
            nums.remove(at: i)
            nums.append(0)
        }
    }
    
}

//var arr1 = [0,1,0,3,0,12]
//moveZeroes(&arr1)

// ******************************************************************************************************

//MARK: - Sum Of two
func sumOfTwo(_ sum : Int , arr : [Int]) -> (Int , Int) {
       
    var tempArr = [Int]()
    for i in 0..<arr.count {
        let temp = sum - arr[i]
        
        if tempArr.contains(temp) {
            return (temp , arr[i])
        }
        
        tempArr.append(arr[i])
    }
    return (0,0)
}

//print(sumOfTwo(10, arr: [2,3,4,5,6,7,8,9]))



// ******************************************************************************************************

//MARK: - associatedtype in swift
protocol ApiMapperProtocol {
    associatedtype T
    associatedtype U
    func MapFromSource(_ : T) -> U
}

class UserMapper: NSObject, ApiMapperProtocol {
    typealias T = NSDictionary
    typealias U = User

    func MapFromSource(_ data : NSDictionary) -> User {
        var user = User(name: "", email: "")
        var accountsData : Array = data.value(forKey: "Accounts") as? Array ?? []
        // For Swift 1.2, you need this line instead
        // var accountsData:NSArray = data["Accounts"] as! NSArray
        return user
    }
}

// ******************************************************************************************************

let addNumber = { (x : Int , y : Int) -> Int in

    return  x + y
}

let c = addNumber(1,3)

// ******************************************************************************************************



/////////////////////////////////
class Alpha {
   unowned let b: Beta
    init(beta: Beta) {
        b = beta
    }
}

class Beta {
    let i: Int = 100
}


func testAlphaWithBeta() {
    let a = Alpha(beta: Beta())
  
    print(a.b.i)
}



//testAlphaWithBeta()

// ******************************************************************************************************

///////////////////////////////////////////
class ABC {
    func getabc() -> String {
        return "base"
    }
}

class BCD: ABC {
    override func getabc() -> String {
        return "child"
    }
}
class Some {
    var bcd: BCD? = BCD()
}

var some = Some()
var bcdCopy = some.bcd

some.bcd = nil

//print((bcdCopy?.getabc()) ?? "bcd nil") // child
//print((some.bcd?.getabc()) ?? "some.bcd nil") // child


// ******************************************************************************************************
//////////////////////////////////////
class Problem {
    
    func delta () {
        
        DispatchQueue.main.async { [unowned self] in
            print("X")
            self.charlie()
            print("Y")
        }
        print("Z")
        charlie()
        print("A")
    }
    
    
    private func charlie (){
    var counter = 0
    for _ in 0..<100000 {
    counter += 1
        
    }
        
    }
    
}
//  X Z Y A
let per = Problem()
per.delta()




/////////////////////////////////////

class testClass {

    func printValue() {

        print("zomato")
    }

}

extension testClass {

    @objc func printAnother () {
        print("print value")
    }

}

class new : testClass {

     override func printAnother() {
        print("zoooo")
    }
}

//let v = new()
//v.printAnother()

////////////////////////////////




protocol MyProAssociate {
   associatedtype T
   func sumOf(x: T, y: T) -> T
}

class MyCls1: MyProAssociate {

   typealias T = Int
   func sumOf(x: Int, y: Int) -> Int {
      return x + y
   }
}

class MyCls2: MyProAssociate {

 typealias T = Float
 func sumOf(x: Float, y: Float) -> Float {
   return x + y
 }
}



protocol addObj {
    //var name : String { get set }
    static func +(lhs: Self, rhs: Self) -> Self
}

extension String: addObj {}
extension Int: addObj {}



func addO <T : addObj> (objA : T , objB : T) -> T {
    
    return objA + objB
    
}


addO(objA: "name", objB: "  Prashant")
addO(objA: 3, objB: 4)

func exitLoop() {
    
outerLoop: for i in 0...100 {
        print( "i" ,  i)
        for j in 0...100 {
            print( "j" ,  j)
            if j == 5 {
                break outerLoop
            }
        }
        
    }
    
    print("value on this ")
}

//exitLoop()


func FlatCompactMap() {
    
    let arr = ["1","two","3","four"]
    
   let newArr = arr.map { obj in
    return Int(obj)
    }
    print(newArr)
    
    let compactArr = arr.compactMap { obj in
        return Int(obj)
    }
    print(compactArr)
    
}

//FlatCompactMap()

//func rotateArr () {
//
//    let arr = [(1,2,3),
//               (4,5,6),
//               (7,8,9)]
//
//    for obj in arr {
//
//        var temp = obj
//
//
//
//    }
//
//
//}

//MARK: - Custom Error :

enum ErrorType : Error {
    
    case valid
    case invalid
    
}


func checkUrl (_ urlString : String ) throws -> Bool {
    
    if let url = URL(string: urlString)  {
    return true
    }else {
        throw ErrorType.invalid
    }
    
}

struct checkURl {
    
    let url : String? = "https:www.googlin"
    let url1 : String? = "https:www.google.in"
    
    func vaildateURl () {
        guard let firstUrl = url , let second = url1 else { return }
        do {
            let vaild = try checkUrl(firstUrl)
            print(vaild)
        }
        catch {
            print(error)
        }
    }
}

let checkingStruct = checkURl()
checkingStruct.vaildateURl()

// Property Observer

var name  : String? {
    didSet {
        print("seted")
    }
    willSet (str) {
        if str!.count  >= 10 {
            print("loong")
        }
    }
}

name = "my name "

// readOnly

public private(set) var hours = 0





// checkout // Array Rotate //
var arrRotate = [1,2,4,5,7,9,8]  // 1452

func rotate(_ arr : inout [Int] , givinNo : Int) -> [Int] {
    
    var tempArr = [Int]()
    var temp1 = [Int]()
    
    if arr.count > givinNo {
        tempArr = Array(arr[0..<givinNo])
        temp1 = Array(arr.dropFirst(givinNo))
        arr.removeAll()
        arr.append(contentsOf: temp1)
        arr.append(contentsOf: tempArr)
    }else {
        print("out of range")
    }
    return arr
}

rotate(&arrRotate, givinNo: 5)

//MARK: Operator Overloading
infix operator **

func **(lhs: Double, rhs: Double) -> Double {
    return pow(lhs, rhs)
}



let re = 2 ** 4

func check() {
    print("CZX")
    DispatchQueue.main.async {
        print("IO")
        DispatchQueue.main.async{
            print("PO")
        }
        DispatchQueue.global().sync{
            print("pe")
        }
        print("Wt")
    }
    print("Abc")
}
check()

// Protocol Extension .
protocol teachers {
    
    func printMyvalue()
}

extension teachers {
    
   func printMyvalue () {
        
       print("func used")
       
    }
}

class class1 : teachers {
    
    var name  : String?
    

    init (_ name  : String ) {
        
        self.name = name
        
    }
    
    
}
let c1 = class1("ma")
c1.printMyvalue()

//MARK: - Closure Problems

func execute () -> (Int) -> Int {
    
    var input = 0
    return   { output in
        return input + output
    }
    
}

let a = execute()
let b = a(2)
let d = a(4)
let e = a(6)


var myName = "Prashant"
var cl = "my"
let closure = { [myName , cl] in
    print("my name is \(myName)")
    print(cl)
}


myName = "iOS"
cl = "oops"
let obj: () = closure()
print(obj)

print("again \(myName), \(cl)")

//MARK: - Convert String inyo romon

func convertIntToRoman(_ num : inout Int) -> String? {
    
    let mappingList = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"), (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]
    
    var romanStr = ""
    
    for i in mappingList {
        while num >= i.0 {
            num -= i.0
            romanStr += i.1
        }
    }
    return romanStr
    
}
var num = 2204
convertIntToRoman(&num)


